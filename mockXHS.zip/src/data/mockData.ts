export const mockNotes = [
  {
    id: '1',
    title: '秋日穿搭分享 | 温柔奶茶色系搭配',
    content: '最近很喜欢这种温柔的奶茶色系，给人很舒服的感觉～分享几套日常穿搭给大家参考',
    images: [
      'https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?w=400&h=600&fit=crop',
      'https://images.unsplash.com/photo-1469334031218-e382a71b716b?w=400&h=600&fit=crop'
    ],
    author: {
      id: 'user1',
      name: '小红薯123',
      avatar: 'https://images.unsplash.com/photo-1494790108755-2616b612b786?w=100&h=100&fit=crop&crop=face'
    },
    likes: 1234,
    liked: false,
    collected: false,
    tags: ['穿搭', '秋日搭配', '奶茶色'],
    createdAt: '2024-01-20'
  },
  {
    id: '2',
    title: '超好用的平价护肤品推荐！学生党必看',
    content: '整理了一些性价比超高的护肤品，都是我自己用过觉得不错的，分享给大家～',
    images: [
      'https://images.unsplash.com/photo-1556228578-8c89e6adf883?w=400&h=500&fit=crop'
    ],
    author: {
      id: 'user2',
      name: '美妆小达人',
      avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop&crop=face'
    },
    likes: 856,
    liked: true,
    collected: false,
    tags: ['护肤', '平价好物', '学生党'],
    createdAt: '2024-01-19'
  },
  {
    id: '3',
    title: '在家也能做的简单美食 | 芝士焗红薯',
    content: '超级简单的芝士焗红薯做法，香甜软糯，奶香浓郁，一口一个停不下来！',
    images: [
      'https://images.unsplash.com/photo-1565299624946-b28f40a0ca4b?w=400&h=600&fit=crop'
    ],
    author: {
      id: 'user3',
      name: '厨房小白',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop&crop=face'
    },
    likes: 2341,
    liked: false,
    collected: true,
    tags: ['美食', '简单料理', '芝士'],
    createdAt: '2024-01-18'
  },
  {
    id: '4',
    title: '日本旅行攻略 | 东京必去的小众咖啡店',
    content: '分享几家在东京发现的超棒咖啡店，环境很棒，咖啡也很好喝，推荐给爱喝咖啡的朋友们',
    images: [
      'https://images.unsplash.com/photo-1501339847302-ac426a4a7cbb?w=400&h=500&fit=crop',
      'https://images.unsplash.com/photo-1554118811-1e0d58224f24?w=400&h=500&fit=crop'
    ],
    author: {
      id: 'user4',
      name: '旅行日记',
      avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop&crop=face'
    },
    likes: 567,
    liked: false,
    collected: false,
    tags: ['旅行', '东京', '咖啡店'],
    createdAt: '2024-01-17'
  },
  {
    id: '5',
    title: '宿舍改造 | 10㎡小空间也能很温馨',
    content: '用有限的预算改造了宿舍，虽然空间不大但是住起来很舒服，分享一些小技巧给大家',
    images: [
      'https://images.unsplash.com/photo-1586023492125-27b2c045efd7?w=400&h=600&fit=crop'
    ],
    author: {
      id: 'user5',
      name: '宿舍装修师',
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&h=100&fit=crop&crop=face'
    },
    likes: 1890,
    liked: true,
    collected: true,
    tags: ['家居', '宿舍改造', '收纳'],
    createdAt: '2024-01-16'
  },
  {
    id: '6',
    title: '健身小白的减脂餐分享',
    content: '坚持健身3个月了，分享一些我常做的减脂餐，营养均衡又好吃，一起加油！',
    images: [
      'https://images.unsplash.com/photo-1490645935967-10de6ba17061?w=400&h=500&fit=crop'
    ],
    author: {
      id: 'user6',
      name: '健身达人',
      avatar: 'https://images.unsplash.com/photo-1489424731084-a5d8b219a5bb?w=100&h=100&fit=crop&crop=face'
    },
    likes: 743,
    liked: false,
    collected: false,
    tags: ['健身', '减脂餐', '健康'],
    createdAt: '2024-01-15'
  },
  {
    id: '7',
    title: '手机摄影技巧 | 如何拍出ins风照片',
    content: '不需要专业相机，用手机也能拍出很棒的照片！分享一些实用的拍照技巧',
    images: [
      'https://images.unsplash.com/photo-1516035069371-29a1b244cc32?w=400&h=600&fit=crop'
    ],
    author: {
      id: 'user7',
      name: '摄影爱好者',
      avatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=100&h=100&fit=crop&crop=face'
    },
    likes: 1456,
    liked: false,
    collected: false,
    tags: ['摄影', '手机拍照', 'ins风'],
    createdAt: '2024-01-14'
  },
  {
    id: '8',
    title: '冬日护肤 | 干皮救星产品推荐',
    content: '冬天皮肤特别干燥，推荐几款我用过很好用的保湿产品，干皮姐妹们可以试试',
    images: [
      'https://images.unsplash.com/photo-1570194065650-d99fb4bedf0a?w=400&h=500&fit=crop'
    ],
    author: {
      id: 'user8',
      name: '护肤小能手',
      avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=100&h=100&fit=crop&crop=face'
    },
    likes: 892,
    liked: true,
    collected: false,
    tags: ['护肤', '保湿', '干皮'],
    createdAt: '2024-01-13'
  }
];

export const mockUsers = [
  {
    id: 'user1',
    name: '小红薯123',
    avatar: 'https://images.unsplash.com/photo-1494790108755-2616b612b786?w=100&h=100&fit=crop&crop=face',
    followers: 1234,
    following: 567,
    likes: 8901,
    bio: '分享生活中的美好时刻 ✨',
    verified: false
  }
];

export const mockMessages = [
  {
    id: '1',
    user: {
      id: 'user2',
      name: '美妆小达人',
      avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop&crop=face'
    },
    lastMessage: '谢谢你的点赞！',
    time: '刚刚',
    unread: true
  },
  {
    id: '2',
    user: {
      id: 'user3',
      name: '厨房小白',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop&crop=face'
    },
    lastMessage: '这个食谱真的很棒！',
    time: '5分钟前',
    unread: false
  }
];

export const mockProducts = [
  {
    id: '1',
    name: '韩式清新淡妆口红套装 持久不脱色',
    price: 89,
    originalPrice: 129,
    image: 'https://images.unsplash.com/photo-1586495777744-4413f21062fa?w=400&h=400&fit=crop',
    rating: 4.8,
    sales: 2341,
    category: '美妆',
    tags: ['热销', '新品'],
    shop: {
      name: '美妆小铺',
      avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop&crop=face'
    }
  },
  {
    id: '2',
    name: '秋冬新款羊毛大衣 修身显瘦',
    price: 299,
    originalPrice: 599,
    image: 'https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?w=400&h=400&fit=crop',
    rating: 4.6,
    sales: 856,
    category: '服饰',
    tags: ['限时特价'],
    shop: {
      name: '时尚女装',
      avatar: 'https://images.unsplash.com/photo-1494790108755-2616b612b786?w=100&h=100&fit=crop&crop=face'
    }
  },
  {
    id: '3',
    name: 'iPhone 15 Pro 钛金属 256GB',
    price: 8999,
    image: 'https://images.unsplash.com/photo-1592750475338-74b7b21085ab?w=400&h=400&fit=crop',
    rating: 4.9,
    sales: 1234,
    category: '数码',
    tags: ['官方正品'],
    shop: {
      name: '数码专营店',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop&crop=face'
    }
  },
  {
    id: '4',
    name: '北欧风简约台灯 护眼学习灯',
    price: 159,
    originalPrice: 299,
    image: 'https://images.unsplash.com/photo-1586023492125-27b2c045efd7?w=400&h=400&fit=crop',
    rating: 4.7,
    sales: 567,
    category: '家居',
    tags: ['护眼', '节能'],
    shop: {
      name: '家居生活馆',
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&h=100&fit=crop&crop=face'
    }
  },
  {
    id: '5',
    name: '手工曲奇饼干礼盒装 多种口味',
    price: 68,
    image: 'https://images.unsplash.com/photo-1565299624946-b28f40a0ca4b?w=400&h=400&fit=crop',
    rating: 4.5,
    sales: 3421,
    category: '美食',
    tags: ['手工制作', '礼盒装'],
    shop: {
      name: '甜品工坊',
      avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop&crop=face'
    }
  },
  {
    id: '6',
    name: '专业瑜伽垫 防滑加厚 10mm',
    price: 128,
    originalPrice: 198,
    image: 'https://images.unsplash.com/photo-1544367567-0f2fcb009e0b?w=400&h=400&fit=crop',
    rating: 4.8,
    sales: 892,
    category: '运动',
    tags: ['防滑', '加厚'],
    shop: {
      name: '运动健身',
      avatar: 'https://images.unsplash.com/photo-1489424731084-a5d8b219a5bb?w=100&h=100&fit=crop&crop=face'
    }
  },
  {
    id: '7',
    name: '婴儿纯棉连体衣 新生儿套装',
    price: 89,
    image: 'https://images.unsplash.com/photo-1522771739844-6a9f6d5f14af?w=400&h=400&fit=crop',
    rating: 4.9,
    sales: 1567,
    category: '母婴',
    tags: ['纯棉', '新生儿'],
    shop: {
      name: '母婴专营',
      avatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=100&h=100&fit=crop&crop=face'
    }
  },
  {
    id: '8',
    name: '蓝牙无线耳机 降噪音质好',
    price: 199,
    originalPrice: 399,
    image: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=400&h=400&fit=crop',
    rating: 4.6,
    sales: 2134,
    category: '数码',
    tags: ['降噪', '无线'],
    shop: {
      name: '数码配件',
      avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=100&h=100&fit=crop&crop=face'
    }
  }
];