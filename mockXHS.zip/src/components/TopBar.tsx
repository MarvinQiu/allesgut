import React from 'react';
import { useNavigate, useLocation } from 'react-router-dom';

const TopBar: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation();

  const getTitle = () => {
    switch (location.pathname) {
      case '/':
        return '首页';
      case '/mall':
        return '市集';
      case '/messages':
        return '消息';
      case '/profile':
        return '我';
      default:
        return '小红书';
    }
  };

  const showSearch = location.pathname === '/' || location.pathname === '/mall';

  return (
    <div className="top-safe-area bg-white border-b border-xiaohongshu-border sticky top-0 z-50">
      <div className="flex items-center justify-between px-4 py-3">
        <div className="flex items-center space-x-3">
          <div className="text-xl font-bold gradient-text">
            小红书
          </div>
        </div>

        <div className="flex items-center space-x-3">
          {showSearch && (
            <button
              onClick={() => navigate('/search')}
              className="flex items-center bg-xiaohongshu-gray-50 rounded-full px-4 py-2 min-w-0 flex-1 max-w-xs"
            >
              <svg className="w-4 h-4 text-xiaohongshu-text-light mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
              </svg>
              <span className="text-xiaohongshu-text-light text-sm">搜索商品、用户、笔记</span>
            </button>
          )}
          
          <button className="p-2">
            <svg className="w-6 h-6 text-xiaohongshu-text-secondary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 17h5l-5 5v-5z" />
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 7H4l5-5v5z" />
            </svg>
          </button>
        </div>
      </div>
    </div>
  );
};

export default TopBar;