import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

interface Product {
  id: string;
  name: string;
  price: number;
  originalPrice?: number;
  image: string;
  rating: number;
  sales: number;
  category: string;
  tags: string[];
  shop: {
    name: string;
    avatar: string;
  };
}

interface ProductCardProps {
  product: Product;
  onAddToCart: (productId: string) => void;
  onBuyNow: (productId: string) => void;
}

const ProductCard: React.FC<ProductCardProps> = ({ product, onAddToCart, onBuyNow }) => {
  const navigate = useNavigate();
  const [imageLoaded, setImageLoaded] = useState(false);

  const handleCardClick = () => {
    navigate(`/product/${product.id}`);
  };

  const handleAddToCart = (e: React.MouseEvent) => {
    e.stopPropagation();
    onAddToCart(product.id);
  };

  const handleBuyNow = (e: React.MouseEvent) => {
    e.stopPropagation();
    onBuyNow(product.id);
  };

  const discount = product.originalPrice 
    ? Math.round((1 - product.price / product.originalPrice) * 100)
    : 0;

  return (
    <div 
      className="xiaohongshu-card cursor-pointer overflow-hidden"
      onClick={handleCardClick}
    >
      {/* 商品图片 */}
      <div className="relative">
        {!imageLoaded && (
          <div className="image-placeholder w-full h-40 rounded-t-xiaohongshu"></div>
        )}
        <img
          src={product.image}
          alt={product.name}
          className={`w-full h-40 object-cover rounded-t-xiaohongshu ${imageLoaded ? 'block' : 'hidden'}`}
          onLoad={() => setImageLoaded(true)}
          loading="lazy"
        />
        
        {/* 折扣标签 */}
        {discount > 0 && (
          <div className="absolute top-2 left-2 bg-xiaohongshu-primary text-white text-xs px-2 py-1 rounded">
            {discount}折
          </div>
        )}

        {/* 标签 */}
        {product.tags.length > 0 && (
          <div className="absolute bottom-2 left-2">
            <span className="bg-black bg-opacity-50 text-white text-xs px-2 py-1 rounded">
              {product.tags[0]}
            </span>
          </div>
        )}
      </div>

      {/* 商品信息 */}
      <div className="p-3">
        {/* 商品名称 */}
        <h3 className="text-xiaohongshu-text-primary font-medium text-sm line-clamp-2 mb-2">
          {product.name}
        </h3>

        {/* 价格信息 */}
        <div className="flex items-baseline space-x-2 mb-2">
          <span className="text-xiaohongshu-primary font-bold text-lg">
            ¥{product.price}
          </span>
          {product.originalPrice && (
            <span className="text-xiaohongshu-text-light text-sm line-through">
              ¥{product.originalPrice}
            </span>
          )}
        </div>

        {/* 评分和销量 */}
        <div className="flex items-center justify-between text-xs text-xiaohongshu-text-light mb-3">
          <div className="flex items-center space-x-1">
            <span className="text-yellow-500">⭐</span>
            <span>{product.rating}</span>
          </div>
          <span>{product.sales}人已购买</span>
        </div>

        {/* 店铺信息 */}
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <img
              src={product.shop.avatar}
              alt={product.shop.name}
              className="w-5 h-5 avatar"
            />
            <span className="text-xiaohongshu-text-secondary text-xs">
              {product.shop.name}
            </span>
          </div>

          {/* 操作按钮 */}
          <div className="flex items-center space-x-2">
            <button
              onClick={handleAddToCart}
              className="p-1.5 bg-xiaohongshu-gray-100 rounded-full hover:bg-xiaohongshu-gray-200 transition-colors"
            >
              <svg className="w-4 h-4 text-xiaohongshu-text-secondary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 3h2l.4 2M7 13h10l4-8H5.4m0 0L7 13m0 0l-2.5 5M7 13l2.5 5m6-5v6a2 2 0 11-4 0v-6m4 0V9a2 2 0 10-4 0v4.01" />
              </svg>
            </button>
            
            <button
              onClick={handleBuyNow}
              className="px-3 py-1.5 xiaohongshu-button text-xs"
            >
              购买
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProductCard;