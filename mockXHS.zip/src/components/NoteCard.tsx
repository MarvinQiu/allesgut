import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

interface Note {
  id: string;
  title: string;
  content: string;
  images: string[];
  author: {
    id: string;
    name: string;
    avatar: string;
  };
  likes: number;
  liked: boolean;
  collected: boolean;
  tags: string[];
  createdAt: string;
}

interface NoteCardProps {
  note: Note;
  onLike: (noteId: string) => void;
  onCollect: (noteId: string) => void;
}

const NoteCard: React.FC<NoteCardProps> = ({ note, onLike, onCollect }) => {
  const navigate = useNavigate();
  const [imageLoaded, setImageLoaded] = useState(false);

  const handleCardClick = () => {
    navigate(`/note/${note.id}`);
  };

  const handleLikeClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    onLike(note.id);
  };

  const handleCollectClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    onCollect(note.id);
  };

  return (
    <div 
      className="xiaohongshu-card cursor-pointer overflow-hidden"
      onClick={handleCardClick}
    >
      {/* 图片 */}
      <div className="relative">
        {!imageLoaded && (
          <div className="image-placeholder w-full h-48 rounded-t-xiaohongshu"></div>
        )}
        <img
          src={note.images[0]}
          alt={note.title}
          className={`w-full h-auto object-cover rounded-t-xiaohongshu ${imageLoaded ? 'block' : 'hidden'}`}
          onLoad={() => setImageLoaded(true)}
          loading="lazy"
        />
        
        {/* 多图标识 */}
        {note.images.length > 1 && (
          <div className="absolute top-2 right-2 bg-black bg-opacity-50 text-white text-xs px-2 py-1 rounded-full">
            1/{note.images.length}
          </div>
        )}
      </div>

      {/* 内容 */}
      <div className="p-3">
        {/* 标题 */}
        <h3 className="text-xiaohongshu-text-primary font-medium text-sm line-clamp-2 mb-2">
          {note.title}
        </h3>

        {/* 标签 */}
        {note.tags.length > 0 && (
          <div className="flex flex-wrap gap-1 mb-3">
            {note.tags.slice(0, 2).map((tag, index) => (
              <span key={index} className="xiaohongshu-tag">
                #{tag}
              </span>
            ))}
          </div>
        )}

        {/* 作者信息和互动 */}
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <img
              src={note.author.avatar}
              alt={note.author.name}
              className="w-6 h-6 avatar"
            />
            <span className="text-xiaohongshu-text-secondary text-xs">
              {note.author.name}
            </span>
          </div>

          <div className="flex items-center space-x-3">
            <button
              onClick={handleLikeClick}
              className={`flex items-center space-x-1 ${note.liked ? 'like-animation' : ''}`}
            >
              <svg 
                className={`w-4 h-4 ${note.liked ? 'text-xiaohongshu-primary' : 'text-xiaohongshu-text-light'}`} 
                fill={note.liked ? 'currentColor' : 'none'} 
                stroke="currentColor" 
                viewBox="0 0 24 24"
              >
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
              </svg>
              <span className={`text-xs ${note.liked ? 'text-xiaohongshu-primary' : 'text-xiaohongshu-text-light'}`}>
                {note.likes}
              </span>
            </button>

            <button onClick={handleCollectClick}>
              <svg 
                className={`w-4 h-4 ${note.collected ? 'text-xiaohongshu-primary' : 'text-xiaohongshu-text-light'}`} 
                fill={note.collected ? 'currentColor' : 'none'} 
                stroke="currentColor" 
                viewBox="0 0 24 24"
              >
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 5a2 2 0 012-2h10a2 2 0 012 2v16l-7-3.5L5 21V5z" />
              </svg>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default NoteCard;