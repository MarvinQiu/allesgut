import React from 'react';
import { Outlet, useLocation } from 'react-router-dom';
import BottomNavigation from './BottomNavigation';
import TopBar from './TopBar';

const Layout: React.FC = () => {
  const location = useLocation();
  const hideTopBar = ['/publish'].includes(location.pathname);

  return (
    <div className="flex flex-col min-h-screen">
      {!hideTopBar && <TopBar />}
      <main className="flex-1 pb-16">
        <Outlet />
      </main>
      <BottomNavigation />
    </div>
  );
};

export default Layout;