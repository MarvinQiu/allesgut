import React from 'react';
import { Routes, Route } from 'react-router-dom';
import Layout from './components/Layout';
import Home from './pages/Home';
import Mall from './pages/Mall';
import Publish from './pages/Publish';
import Messages from './pages/Messages';
import Profile from './pages/Profile';
import NoteDetail from './pages/NoteDetail';
import Search from './pages/Search';
import ProductDetail from './pages/ProductDetail';

const App: React.FC = () => {
  return (
    <div className="min-h-screen bg-xiaohongshu-background">
      <Routes>
        <Route path="/" element={<Layout />}>
          <Route index element={<Home />} />
          <Route path="mall" element={<Mall />} />
          <Route path="publish" element={<Publish />} />
          <Route path="messages" element={<Messages />} />
          <Route path="profile" element={<Profile />} />
        </Route>
        <Route path="/note/:id" element={<NoteDetail />} />
        <Route path="/product/:id" element={<ProductDetail />} />
        <Route path="/search" element={<Search />} />
      </Routes>
    </div>
  );
};

export default App;