import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { mockNotes } from '../data/mockData';

const Search: React.FC = () => {
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState('');
  const [activeTab, setActiveTab] = useState('综合');
  const [searchResults, setSearchResults] = useState(mockNotes);

  const tabs = ['综合', '用户', '商品', '话题'];
  const hotSearches = ['秋日穿搭', '护肤心得', '减脂餐', '旅行攻略', '家居改造', '美妆教程'];

  const handleSearch = (query: string) => {
    setSearchQuery(query);
    // 模拟搜索结果
    const results = mockNotes.filter(note => 
      note.title.includes(query) || 
      note.content.includes(query) ||
      note.tags.some(tag => tag.includes(query))
    );
    setSearchResults(results);
  };

  return (
    <div className="min-h-screen bg-xiaohongshu-background">
      {/* 搜索头部 */}
      <div className="top-safe-area bg-white border-b border-xiaohongshu-border sticky top-0 z-50">
        <div className="flex items-center px-4 py-3 space-x-3">
          <button 
            onClick={() => navigate(-1)}
            className="p-1"
          >
            <svg className="w-6 h-6 text-xiaohongshu-text-secondary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
            </svg>
          </button>
          
          <div className="flex-1 relative">
            <input
              type="text"
              placeholder="搜索商品、用户、笔记"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleSearch(searchQuery)}
              className="search-input w-full"
              autoFocus
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-1/2 transform -translate-y-1/2"
              >
                <svg className="w-4 h-4 text-xiaohongshu-text-light" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            )}
          </div>
          
          <button 
            onClick={() => handleSearch(searchQuery)}
            className="text-xiaohongshu-primary font-medium"
          >
            搜索
          </button>
        </div>
      </div>

      {/* 搜索内容 */}
      {!searchQuery ? (
        /* 搜索首页 */
        <div className="p-4">
          {/* 热门搜索 */}
          <div className="mb-6">
            <h3 className="text-xiaohongshu-text-primary font-medium mb-3">热门搜索</h3>
            <div className="flex flex-wrap gap-2">
              {hotSearches.map((search, index) => (
                <button
                  key={index}
                  onClick={() => handleSearch(search)}
                  className="bg-xiaohongshu-gray-50 text-xiaohongshu-text-secondary px-3 py-2 rounded-full text-sm hover:bg-xiaohongshu-gray-100"
                >
                  {search}
                </button>
              ))}
            </div>
          </div>

          {/* 搜索历史 */}
          <div>
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-xiaohongshu-text-primary font-medium">搜索历史</h3>
              <button className="text-xiaohongshu-text-light text-sm">清空</button>
            </div>
            
            <div className="space-y-3">
              {['护肤心得', '秋日穿搭'].map((history, index) => (
                <div key={index} className="flex items-center justify-between">
                  <button
                    onClick={() => handleSearch(history)}
                    className="flex items-center space-x-3 flex-1"
                  >
                    <svg className="w-4 h-4 text-xiaohongshu-text-light" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                    <span className="text-xiaohongshu-text-secondary">{history}</span>
                  </button>
                  <button className="p-1">
                    <svg className="w-4 h-4 text-xiaohongshu-text-light" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                    </svg>
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>
      ) : (
        /* 搜索结果 */
        <div>
          {/* 标签切换 */}
          <div className="bg-white px-4 py-3 border-b border-xiaohongshu-border">
            <div className="flex space-x-6">
              {tabs.map((tab) => (
                <button
                  key={tab}
                  onClick={() => setActiveTab(tab)}
                  className={`pb-2 text-sm font-medium transition-colors relative ${
                    activeTab === tab 
                      ? 'text-xiaohongshu-primary' 
                      : 'text-xiaohongshu-text-secondary'
                  }`}
                >
                  {tab}
                  {activeTab === tab && (
                    <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-xiaohongshu-primary rounded-full"></div>
                  )}
                </button>
              ))}
            </div>
          </div>

          {/* 搜索结果 */}
          <div className="p-4">
            {searchResults.length > 0 ? (
              <div className="grid grid-cols-2 gap-3">
                {searchResults.map((note) => (
                  <div 
                    key={note.id} 
                    className="xiaohongshu-card overflow-hidden cursor-pointer"
                    onClick={() => navigate(`/note/${note.id}`)}
                  >
                    <img
                      src={note.images[0]}
                      alt={note.title}
                      className="w-full h-32 object-cover"
                    />
                    <div className="p-2">
                      <h4 className="text-xiaohongshu-text-primary text-xs font-medium line-clamp-2 mb-1">
                        {note.title}
                      </h4>
                      <div className="flex items-center space-x-1">
                        <img
                          src={note.author.avatar}
                          alt={note.author.name}
                          className="w-4 h-4 avatar"
                        />
                        <span className="text-xiaohongshu-text-light text-xs">
                          {note.author.name}
                        </span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center py-20">
                <div className="text-6xl mb-4">🔍</div>
                <p className="text-xiaohongshu-text-light text-sm">没有找到相关内容</p>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export default Search;