import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

const Publish: React.FC = () => {
  const navigate = useNavigate();
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [images, setImages] = useState<string[]>([]);
  const [tags, setTags] = useState<string[]>([]);
  const [currentTag, setCurrentTag] = useState('');

  const handleAddTag = () => {
    if (currentTag.trim() && !tags.includes(currentTag.trim())) {
      setTags([...tags, currentTag.trim()]);
      setCurrentTag('');
    }
  };

  const handleRemoveTag = (tagToRemove: string) => {
    setTags(tags.filter(tag => tag !== tagToRemove));
  };

  const handlePublish = () => {
    // 这里处理发布逻辑
    console.log('发布笔记:', { title, content, images, tags });
    navigate('/');
  };

  return (
    <div className="min-h-screen bg-xiaohongshu-background">
      {/* 顶部导航 */}
      <div className="top-safe-area bg-white border-b border-xiaohongshu-border sticky top-0 z-50">
        <div className="flex items-center justify-between px-4 py-3">
          <button 
            onClick={() => navigate(-1)}
            className="text-xiaohongshu-text-secondary"
          >
            取消
          </button>
          <h1 className="text-xiaohongshu-text-primary font-medium">发布笔记</h1>
          <button 
            onClick={handlePublish}
            className="text-xiaohongshu-primary font-medium"
            disabled={!title.trim() || !content.trim()}
          >
            发布
          </button>
        </div>
      </div>

      <div className="p-4 space-y-6">
        {/* 图片上传 */}
        <div className="bg-white rounded-xiaohongshu p-4">
          <h3 className="text-xiaohongshu-text-primary font-medium mb-3">添加图片</h3>
          <div className="grid grid-cols-3 gap-3">
            {images.map((image, index) => (
              <div key={index} className="relative aspect-square">
                <img
                  src={image}
                  alt={`上传图片 ${index + 1}`}
                  className="w-full h-full object-cover rounded-lg"
                />
                <button
                  onClick={() => setImages(images.filter((_, i) => i !== index))}
                  className="absolute -top-2 -right-2 w-6 h-6 bg-xiaohongshu-primary rounded-full flex items-center justify-center"
                >
                  <svg className="w-4 h-4 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                  </svg>
                </button>
              </div>
            ))}
            
            {images.length < 9 && (
              <button
                onClick={() => {
                  // 模拟图片上传
                  const newImage = `https://images.unsplash.com/photo-${Date.now()}?w=400&h=400&fit=crop`;
                  setImages([...images, newImage]);
                }}
                className="aspect-square border-2 border-dashed border-xiaohongshu-border rounded-lg flex flex-col items-center justify-center text-xiaohongshu-text-light"
              >
                <svg className="w-8 h-8 mb-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
                </svg>
                <span className="text-xs">添加图片</span>
              </button>
            )}
          </div>
        </div>

        {/* 标题输入 */}
        <div className="bg-white rounded-xiaohongshu p-4">
          <input
            type="text"
            placeholder="填写标题，会有更多赞哦～"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            className="w-full text-xiaohongshu-text-primary font-medium text-lg placeholder-xiaohongshu-text-light border-none outline-none"
            maxLength={50}
          />
          <div className="text-right text-xiaohongshu-text-light text-xs mt-2">
            {title.length}/50
          </div>
        </div>

        {/* 内容输入 */}
        <div className="bg-white rounded-xiaohongshu p-4">
          <textarea
            placeholder="添加正文内容..."
            value={content}
            onChange={(e) => setContent(e.target.value)}
            className="w-full h-32 text-xiaohongshu-text-primary placeholder-xiaohongshu-text-light border-none outline-none resize-none"
            maxLength={1000}
          />
          <div className="text-right text-xiaohongshu-text-light text-xs mt-2">
            {content.length}/1000
          </div>
        </div>

        {/* 标签输入 */}
        <div className="bg-white rounded-xiaohongshu p-4">
          <h3 className="text-xiaohongshu-text-primary font-medium mb-3">添加标签</h3>
          
          {/* 已添加的标签 */}
          {tags.length > 0 && (
            <div className="flex flex-wrap gap-2 mb-3">
              {tags.map((tag) => (
                <div key={tag} className="flex items-center bg-xiaohongshu-gray-50 rounded-full px-3 py-1">
                  <span className="text-xiaohongshu-text-secondary text-sm">#{tag}</span>
                  <button
                    onClick={() => handleRemoveTag(tag)}
                    className="ml-2 text-xiaohongshu-text-light"
                  >
                    <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                    </svg>
                  </button>
                </div>
              ))}
            </div>
          )}
          
          {/* 标签输入框 */}
          <div className="flex space-x-2">
            <input
              type="text"
              placeholder="输入标签"
              value={currentTag}
              onChange={(e) => setCurrentTag(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleAddTag()}
              className="flex-1 px-3 py-2 bg-xiaohongshu-gray-50 rounded-lg text-xiaohongshu-text-primary placeholder-xiaohongshu-text-light border-none outline-none"
            />
            <button
              onClick={handleAddTag}
              disabled={!currentTag.trim() || tags.length >= 10}
              className="px-4 py-2 bg-xiaohongshu-primary text-white rounded-lg text-sm disabled:opacity-50"
            >
              添加
            </button>
          </div>
          
          <div className="text-xiaohongshu-text-light text-xs mt-2">
            最多可添加10个标签，当前已添加{tags.length}个
          </div>
        </div>

        {/* 其他设置 */}
        <div className="bg-white rounded-xiaohongshu p-4">
          <h3 className="text-xiaohongshu-text-primary font-medium mb-3">其他设置</h3>
          
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-xiaohongshu-text-secondary">允许评论</span>
              <div className="w-12 h-6 bg-xiaohongshu-primary rounded-full relative">
                <div className="w-5 h-5 bg-white rounded-full absolute right-0.5 top-0.5"></div>
              </div>
            </div>
            
            <div className="flex items-center justify-between">
              <span className="text-xiaohongshu-text-secondary">同步到动态</span>
              <div className="w-12 h-6 bg-xiaohongshu-gray-200 rounded-full relative">
                <div className="w-5 h-5 bg-white rounded-full absolute left-0.5 top-0.5"></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Publish;