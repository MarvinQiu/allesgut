import React, { useState, useEffect } from 'react';
import NoteCard from '../components/NoteCard';
import { mockNotes } from '../data/mockData';

const Home: React.FC = () => {
  const [notes, setNotes] = useState(mockNotes);
  const [loading, setLoading] = useState(false);

  const handleLike = (noteId: string) => {
    setNotes(prev => prev.map(note => 
      note.id === noteId 
        ? { ...note, liked: !note.liked, likes: note.liked ? note.likes - 1 : note.likes + 1 }
        : note
    ));
  };

  const handleCollect = (noteId: string) => {
    setNotes(prev => prev.map(note => 
      note.id === noteId 
        ? { ...note, collected: !note.collected }
        : note
    ));
  };

  return (
    <div className="min-h-screen bg-xiaohongshu-background">
      {/* 分类标签 */}
      <div className="bg-white px-4 py-3 border-b border-xiaohongshu-border">
        <div className="flex space-x-4 overflow-x-auto">
          {['推荐', '穿搭', '美妆', '美食', '旅行', '家居', '健身', '摄影'].map((category, index) => (
            <button
              key={category}
              className={`whitespace-nowrap px-4 py-2 rounded-full text-sm font-medium transition-colors ${
                index === 0 
                  ? 'bg-xiaohongshu-primary text-white' 
                  : 'bg-xiaohongshu-gray-50 text-xiaohongshu-text-secondary hover:bg-xiaohongshu-gray-100'
              }`}
            >
              {category}
            </button>
          ))}
        </div>
      </div>

      {/* 瀑布流内容 */}
      <div className="waterfall-container py-4">
        {notes.map((note) => (
          <div key={note.id} className="waterfall-item">
            <NoteCard 
              note={note} 
              onLike={handleLike}
              onCollect={handleCollect}
            />
          </div>
        ))}
      </div>

      {/* 加载更多 */}
      {loading && (
        <div className="flex justify-center py-8">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-xiaohongshu-primary"></div>
        </div>
      )}
    </div>
  );
};

export default Home;