import React, { useState } from 'react';
import ProductCard from '../components/ProductCard';
import { mockProducts } from '../data/mockData';

const Mall: React.FC = () => {
  const [products, setProducts] = useState(mockProducts);
  const [activeCategory, setActiveCategory] = useState('全部');

  const categories = ['全部', '美妆', '服饰', '数码', '家居', '美食', '运动', '母婴'];

  const handleAddToCart = (productId: string) => {
    console.log('添加到购物车:', productId);
  };

  const handleBuyNow = (productId: string) => {
    console.log('立即购买:', productId);
  };

  const filteredProducts = activeCategory === '全部' 
    ? products 
    : products.filter(product => product.category === activeCategory);

  return (
    <div className="min-h-screen bg-xiaohongshu-background">
      {/* 轮播图 */}
      <div className="bg-white">
        <div className="relative h-40 overflow-hidden">
          <img
            src="https://images.unsplash.com/photo-1441986300917-64674bd600d8?w=800&h=320&fit=crop"
            alt="促销活动"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-black/30 to-transparent flex items-center">
            <div className="px-6 text-white">
              <h2 className="text-xl font-bold mb-2">新年特惠</h2>
              <p className="text-sm opacity-90">精选好物 限时优惠</p>
            </div>
          </div>
        </div>
      </div>

      {/* 分类导航 */}
      <div className="bg-white px-4 py-3 border-b border-xiaohongshu-border">
        <div className="flex space-x-4 overflow-x-auto">
          {categories.map((category) => (
            <button
              key={category}
              onClick={() => setActiveCategory(category)}
              className={`whitespace-nowrap px-4 py-2 rounded-full text-sm font-medium transition-colors ${
                activeCategory === category
                  ? 'bg-xiaohongshu-primary text-white' 
                  : 'bg-xiaohongshu-gray-50 text-xiaohongshu-text-secondary hover:bg-xiaohongshu-gray-100'
              }`}
            >
              {category}
            </button>
          ))}
        </div>
      </div>

      {/* 快捷入口 */}
      <div className="bg-white mx-4 mt-4 rounded-xiaohongshu p-4">
        <div className="grid grid-cols-4 gap-4">
          {[
            { icon: '🔥', label: '限时抢购', color: 'bg-red-100 text-red-600' },
            { icon: '💎', label: '品牌特卖', color: 'bg-purple-100 text-purple-600' },
            { icon: '🎁', label: '新人专享', color: 'bg-blue-100 text-blue-600' },
            { icon: '📦', label: '包邮专区', color: 'bg-green-100 text-green-600' }
          ].map((item, index) => (
            <button key={index} className="flex flex-col items-center space-y-2">
              <div className={`w-12 h-12 rounded-full ${item.color} flex items-center justify-center text-xl`}>
                {item.icon}
              </div>
              <span className="text-xiaohongshu-text-secondary text-xs">{item.label}</span>
            </button>
          ))}
        </div>
      </div>

      {/* 商品网格 */}
      <div className="p-4">
        <div className="grid grid-cols-2 gap-3">
          {filteredProducts.map((product) => (
            <ProductCard 
              key={product.id}
              product={product}
              onAddToCart={handleAddToCart}
              onBuyNow={handleBuyNow}
            />
          ))}
        </div>
      </div>

      {/* 加载更多 */}
      <div className="flex justify-center py-8">
        <button className="px-6 py-2 bg-xiaohongshu-gray-100 text-xiaohongshu-text-secondary rounded-full text-sm">
          加载更多商品
        </button>
      </div>
    </div>
  );
};

export default Mall;