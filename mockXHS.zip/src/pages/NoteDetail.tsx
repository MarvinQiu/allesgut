import React, { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { mockNotes } from '../data/mockData';

const NoteDetail: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const note = mockNotes.find(n => n.id === id);
  const [liked, setLiked] = useState(note?.liked || false);
  const [collected, setCollected] = useState(note?.collected || false);
  const [currentImageIndex, setCurrentImageIndex] = useState(0);

  if (!note) {
    return (
      <div className="min-h-screen bg-xiaohongshu-background flex items-center justify-center">
        <div className="text-center">
          <div className="text-6xl mb-4">😅</div>
          <p className="text-xiaohongshu-text-light">笔记不存在</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-xiaohongshu-background">
      {/* 顶部导航 */}
      <div className="top-safe-area bg-white border-b border-xiaohongshu-border sticky top-0 z-50">
        <div className="flex items-center justify-between px-4 py-3">
          <button 
            onClick={() => navigate(-1)}
            className="p-1"
          >
            <svg className="w-6 h-6 text-xiaohongshu-text-secondary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
            </svg>
          </button>
          
          <div className="flex items-center space-x-4">
            <button className="p-1">
              <svg className="w-6 h-6 text-xiaohongshu-text-secondary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8.684 13.342C8.886 12.938 9 12.482 9 12c0-.482-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6l6.632-3.316m0 0a3 3 0 105.367-2.684 3 3 0 00-5.367 2.684zm0 9.316a3 3 0 105.367 2.684 3 3 0 00-5.367-2.684z" />
              </svg>
            </button>
            <button className="p-1">
              <svg className="w-6 h-6 text-xiaohongshu-text-secondary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 12h.01M12 12h.01M19 12h.01M6 12a1 1 0 11-2 0 1 1 0 012 0zm7 0a1 1 0 11-2 0 1 1 0 012 0zm7 0a1 1 0 11-2 0 1 1 0 012 0z" />
              </svg>
            </button>
          </div>
        </div>
      </div>

      <div className="pb-20">
        {/* 图片轮播 */}
        <div className="relative bg-black">
          <img
            src={note.images[currentImageIndex]}
            alt={note.title}
            className="w-full h-96 object-contain"
          />
          
          {note.images.length > 1 && (
            <>
              {/* 图片指示器 */}
              <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 flex space-x-2">
                {note.images.map((_, index) => (
                  <div
                    key={index}
                    className={`w-2 h-2 rounded-full ${
                      index === currentImageIndex ? 'bg-white' : 'bg-white bg-opacity-50'
                    }`}
                  />
                ))}
              </div>
              
              {/* 左右切换按钮 */}
              <button
                onClick={() => setCurrentImageIndex(Math.max(0, currentImageIndex - 1))}
                className="absolute left-4 top-1/2 transform -translate-y-1/2 w-8 h-8 bg-black bg-opacity-50 rounded-full flex items-center justify-center"
                disabled={currentImageIndex === 0}
              >
                <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
                </svg>
              </button>
              
              <button
                onClick={() => setCurrentImageIndex(Math.min(note.images.length - 1, currentImageIndex + 1))}
                className="absolute right-4 top-1/2 transform -translate-y-1/2 w-8 h-8 bg-black bg-opacity-50 rounded-full flex items-center justify-center"
                disabled={currentImageIndex === note.images.length - 1}
              >
                <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                </svg>
              </button>
            </>
          )}
        </div>

        {/* 内容区域 */}
        <div className="bg-white p-4">
          {/* 标题 */}
          <h1 className="text-xiaohongshu-text-primary font-bold text-lg mb-3">
            {note.title}
          </h1>

          {/* 内容 */}
          <p className="text-xiaohongshu-text-secondary leading-relaxed mb-4">
            {note.content}
          </p>

          {/* 标签 */}
          {note.tags.length > 0 && (
            <div className="flex flex-wrap gap-2 mb-4">
              {note.tags.map((tag, index) => (
                <span key={index} className="xiaohongshu-tag">
                  #{tag}
                </span>
              ))}
            </div>
          )}

          {/* 作者信息 */}
          <div className="flex items-center justify-between py-4 border-t border-xiaohongshu-border">
            <div className="flex items-center space-x-3">
              <img
                src={note.author.avatar}
                alt={note.author.name}
                className="w-10 h-10 avatar"
              />
              <div>
                <h3 className="text-xiaohongshu-text-primary font-medium">
                  {note.author.name}
                </h3>
                <p className="text-xiaohongshu-text-light text-xs">
                  {note.createdAt}
                </p>
              </div>
            </div>
            
            <button className="xiaohongshu-button px-6 py-2 text-sm">
              关注
            </button>
          </div>
        </div>

        {/* 评论区域 */}
        <div className="bg-white mt-2 p-4">
          <h3 className="text-xiaohongshu-text-primary font-medium mb-4">评论</h3>
          
          <div className="flex flex-col items-center justify-center py-12">
            <div className="text-6xl mb-4">💬</div>
            <p className="text-xiaohongshu-text-light text-sm">暂无评论，快来抢沙发吧～</p>
          </div>
        </div>
      </div>

      {/* 底部操作栏 */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-xiaohongshu-border p-4">
        <div className="flex items-center space-x-4">
          <div className="flex-1 flex items-center bg-xiaohongshu-gray-50 rounded-full px-4 py-2">
            <input
              type="text"
              placeholder="说点什么..."
              className="flex-1 bg-transparent text-xiaohongshu-text-primary placeholder-xiaohongshu-text-light text-sm border-none outline-none"
            />
          </div>
          
          <button
            onClick={() => setLiked(!liked)}
            className={`p-2 ${liked ? 'like-animation' : ''}`}
          >
            <svg 
              className={`w-6 h-6 ${liked ? 'text-xiaohongshu-primary' : 'text-xiaohongshu-text-light'}`} 
              fill={liked ? 'currentColor' : 'none'} 
              stroke="currentColor" 
              viewBox="0 0 24 24"
            >
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
            </svg>
          </button>
          
          <button onClick={() => setCollected(!collected)}>
            <svg 
              className={`w-6 h-6 ${collected ? 'text-xiaohongshu-primary' : 'text-xiaohongshu-text-light'}`} 
              fill={collected ? 'currentColor' : 'none'} 
              stroke="currentColor" 
              viewBox="0 0 24 24"
            >
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 5a2 2 0 012-2h10a2 2 0 012 2v16l-7-3.5L5 21V5z" />
            </svg>
          </button>
        </div>
      </div>
    </div>
  );
};

export default NoteDetail;