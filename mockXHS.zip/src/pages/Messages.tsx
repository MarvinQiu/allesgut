import React from 'react';
import { mockMessages } from '../data/mockData';

const Messages: React.FC = () => {
  return (
    <div className="min-h-screen bg-xiaohongshu-background">
      {/* 功能入口 */}
      <div className="bg-white px-4 py-4 border-b border-xiaohongshu-border">
        <div className="grid grid-cols-4 gap-4">
          {[
            { icon: '👥', label: '群聊', color: 'bg-blue-100 text-blue-600' },
            { icon: '📢', label: '通知', color: 'bg-green-100 text-green-600' },
            { icon: '❤️', label: '赞和收藏', color: 'bg-red-100 text-red-600' },
            { icon: '💬', label: '评论', color: 'bg-purple-100 text-purple-600' }
          ].map((item, index) => (
            <button key={index} className="flex flex-col items-center space-y-2">
              <div className={`w-12 h-12 rounded-full ${item.color} flex items-center justify-center text-xl`}>
                {item.icon}
              </div>
              <span className="text-xiaohongshu-text-secondary text-xs">{item.label}</span>
            </button>
          ))}
        </div>
      </div>

      {/* 消息列表 */}
      <div className="bg-white">
        <div className="px-4 py-3 border-b border-xiaohongshu-border">
          <h3 className="text-xiaohongshu-text-primary font-medium">消息</h3>
        </div>
        
        {mockMessages.map((message) => (
          <div key={message.id} className="flex items-center px-4 py-3 border-b border-xiaohongshu-border hover:bg-xiaohongshu-gray-50">
            <div className="relative">
              <img
                src={message.user.avatar}
                alt={message.user.name}
                className="w-12 h-12 avatar"
              />
              {message.unread && (
                <div className="absolute -top-1 -right-1 w-3 h-3 bg-xiaohongshu-primary rounded-full"></div>
              )}
            </div>
            
            <div className="flex-1 ml-3">
              <div className="flex items-center justify-between">
                <h4 className="text-xiaohongshu-text-primary font-medium text-sm">
                  {message.user.name}
                </h4>
                <span className="text-xiaohongshu-text-light text-xs">
                  {message.time}
                </span>
              </div>
              <p className="text-xiaohongshu-text-secondary text-sm mt-1">
                {message.lastMessage}
              </p>
            </div>
          </div>
        ))}
      </div>

      {/* 空状态 */}
      <div className="flex flex-col items-center justify-center py-20">
        <div className="text-6xl mb-4">💌</div>
        <p className="text-xiaohongshu-text-light text-sm">暂无更多消息</p>
      </div>
    </div>
  );
};

export default Messages;