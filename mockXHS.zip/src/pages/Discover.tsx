import React, { useState } from 'react';
import NoteCard from '../components/NoteCard';
import { mockNotes } from '../data/mockData';

const Discover: React.FC = () => {
  const [notes, setNotes] = useState(mockNotes);
  const [activeTab, setActiveTab] = useState('推荐');

  const tabs = ['推荐', '关注', '附近', '热门'];

  const handleLike = (noteId: string) => {
    setNotes(prev => prev.map(note => 
      note.id === noteId 
        ? { ...note, liked: !note.liked, likes: note.liked ? note.likes - 1 : note.likes + 1 }
        : note
    ));
  };

  const handleCollect = (noteId: string) => {
    setNotes(prev => prev.map(note => 
      note.id === noteId 
        ? { ...note, collected: !note.collected }
        : note
    ));
  };

  return (
    <div className="min-h-screen bg-xiaohongshu-background">
      {/* 标签切换 */}
      <div className="bg-white px-4 py-3 border-b border-xiaohongshu-border">
        <div className="flex space-x-6">
          {tabs.map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`pb-2 text-sm font-medium transition-colors relative ${
                activeTab === tab 
                  ? 'text-xiaohongshu-primary' 
                  : 'text-xiaohongshu-text-secondary'
              }`}
            >
              {tab}
              {activeTab === tab && (
                <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-xiaohongshu-primary rounded-full"></div>
              )}
            </button>
          ))}
        </div>
      </div>

      {/* 热门话题 */}
      <div className="bg-white px-4 py-3 border-b border-xiaohongshu-border">
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-xiaohongshu-text-primary font-medium">热门话题</h3>
          <button className="text-xiaohongshu-text-light text-sm">更多</button>
        </div>
        <div className="flex space-x-3 overflow-x-auto">
          {['#秋日穿搭', '#护肤心得', '#美食分享', '#旅行攻略', '#家居改造'].map((topic) => (
            <div key={topic} className="flex-shrink-0 bg-xiaohongshu-gray-50 rounded-lg px-3 py-2">
              <span className="text-xiaohongshu-text-secondary text-sm">{topic}</span>
            </div>
          ))}
        </div>
      </div>

      {/* 内容区域 */}
      <div className="waterfall-container py-4">
        {notes.map((note) => (
          <div key={note.id} className="waterfall-item">
            <NoteCard 
              note={note} 
              onLike={handleLike}
              onCollect={handleCollect}
            />
          </div>
        ))}
      </div>
    </div>
  );
};

export default Discover;