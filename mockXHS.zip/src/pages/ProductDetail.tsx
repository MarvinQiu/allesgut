import React, { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { mockProducts } from '../data/mockData';

const ProductDetail: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const product = mockProducts.find(p => p.id === id);
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [selectedSpec, setSelectedSpec] = useState('');
  const [quantity, setQuantity] = useState(1);

  if (!product) {
    return (
      <div className="min-h-screen bg-xiaohongshu-background flex items-center justify-center">
        <div className="text-center">
          <div className="text-6xl mb-4">😅</div>
          <p className="text-xiaohongshu-text-light">商品不存在</p>
        </div>
      </div>
    );
  }

  const images = [product.image, product.image, product.image]; // 模拟多图
  const specs = ['默认规格', '规格A', '规格B']; // 模拟规格

  return (
    <div className="min-h-screen bg-xiaohongshu-background">
      {/* 顶部导航 */}
      <div className="top-safe-area bg-white border-b border-xiaohongshu-border sticky top-0 z-50">
        <div className="flex items-center justify-between px-4 py-3">
          <button 
            onClick={() => navigate(-1)}
            className="p-1"
          >
            <svg className="w-6 h-6 text-xiaohongshu-text-secondary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
            </svg>
          </button>
          
          <div className="flex items-center space-x-4">
            <button className="p-1">
              <svg className="w-6 h-6 text-xiaohongshu-text-secondary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8.684 13.342C8.886 12.938 9 12.482 9 12c0-.482-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6l6.632-3.316m0 0a3 3 0 105.367-2.684 3 3 0 00-5.367 2.684zm0 9.316a3 3 0 105.367 2.684 3 3 0 00-5.367-2.684z" />
              </svg>
            </button>
            <button className="p-1">
              <svg className="w-6 h-6 text-xiaohongshu-text-secondary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 3h2l.4 2M7 13h10l4-8H5.4m0 0L7 13m0 0l-2.5 5M7 13l2.5 5m6-5v6a2 2 0 11-4 0v-6m4 0V9a2 2 0 10-4 0v4.01" />
              </svg>
            </button>
          </div>
        </div>
      </div>

      <div className="pb-20">
        {/* 商品图片轮播 */}
        <div className="relative bg-white">
          <img
            src={images[currentImageIndex]}
            alt={product.name}
            className="w-full h-96 object-cover"
          />
          
          {images.length > 1 && (
            <>
              {/* 图片指示器 */}
              <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 flex space-x-2">
                {images.map((_, index) => (
                  <div
                    key={index}
                    className={`w-2 h-2 rounded-full ${
                      index === currentImageIndex ? 'bg-white' : 'bg-white bg-opacity-50'
                    }`}
                  />
                ))}
              </div>
            </>
          )}
        </div>

        {/* 商品基本信息 */}
        <div className="bg-white p-4 border-b border-xiaohongshu-border">
          <div className="flex items-start justify-between mb-3">
            <div className="flex-1">
              <h1 className="text-xiaohongshu-text-primary font-bold text-lg mb-2">
                {product.name}
              </h1>
              <div className="flex items-baseline space-x-2">
                <span className="text-xiaohongshu-primary font-bold text-2xl">
                  ¥{product.price}
                </span>
                {product.originalPrice && (
                  <span className="text-xiaohongshu-text-light text-sm line-through">
                    ¥{product.originalPrice}
                  </span>
                )}
              </div>
            </div>
            
            <button className="p-2">
              <svg className="w-6 h-6 text-xiaohongshu-text-light" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
              </svg>
            </button>
          </div>

          <div className="flex items-center space-x-4 text-sm text-xiaohongshu-text-secondary">
            <div className="flex items-center space-x-1">
              <span className="text-yellow-500">⭐</span>
              <span>{product.rating}</span>
            </div>
            <span>{product.sales}人已购买</span>
            <span>包邮</span>
          </div>
        </div>

        {/* 规格选择 */}
        <div className="bg-white p-4 border-b border-xiaohongshu-border">
          <h3 className="text-xiaohongshu-text-primary font-medium mb-3">选择规格</h3>
          <div className="flex flex-wrap gap-2">
            {specs.map((spec) => (
              <button
                key={spec}
                onClick={() => setSelectedSpec(spec)}
                className={`px-4 py-2 rounded-lg border transition-colors ${
                  selectedSpec === spec
                    ? 'border-xiaohongshu-primary bg-xiaohongshu-primary bg-opacity-10 text-xiaohongshu-primary'
                    : 'border-xiaohongshu-border text-xiaohongshu-text-secondary'
                }`}
              >
                {spec}
              </button>
            ))}
          </div>
        </div>

        {/* 数量选择 */}
        <div className="bg-white p-4 border-b border-xiaohongshu-border">
          <div className="flex items-center justify-between">
            <h3 className="text-xiaohongshu-text-primary font-medium">数量</h3>
            <div className="flex items-center space-x-3">
              <button
                onClick={() => setQuantity(Math.max(1, quantity - 1))}
                className="w-8 h-8 rounded-full border border-xiaohongshu-border flex items-center justify-center"
              >
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20 12H4" />
                </svg>
              </button>
              <span className="text-xiaohongshu-text-primary font-medium min-w-[2rem] text-center">
                {quantity}
              </span>
              <button
                onClick={() => setQuantity(quantity + 1)}
                className="w-8 h-8 rounded-full border border-xiaohongshu-border flex items-center justify-center"
              >
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
                </svg>
              </button>
            </div>
          </div>
        </div>

        {/* 店铺信息 */}
        <div className="bg-white p-4 border-b border-xiaohongshu-border">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <img
                src={product.shop.avatar}
                alt={product.shop.name}
                className="w-12 h-12 avatar"
              />
              <div>
                <h3 className="text-xiaohongshu-text-primary font-medium">
                  {product.shop.name}
                </h3>
                <p className="text-xiaohongshu-text-light text-xs">
                  好评率 98%
                </p>
              </div>
            </div>
            
            <button className="px-4 py-2 border border-xiaohongshu-border rounded-full text-xiaohongshu-text-secondary text-sm">
              进店看看
            </button>
          </div>
        </div>

        {/* 商品详情 */}
        <div className="bg-white p-4">
          <h3 className="text-xiaohongshu-text-primary font-medium mb-4">商品详情</h3>
          
          <div className="space-y-4">
            <img
              src={product.image}
              alt="商品详情"
              className="w-full rounded-lg"
            />
            <p className="text-xiaohongshu-text-secondary leading-relaxed">
              这是一款精心挑选的优质商品，采用优质材料制作，工艺精良，品质保证。
              适合日常使用，是您生活中的好帮手。我们承诺为您提供最优质的产品和服务。
            </p>
          </div>
        </div>
      </div>

      {/* 底部操作栏 */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-xiaohongshu-border p-4">
        <div className="flex items-center space-x-3">
          <button className="flex-1 py-3 border border-xiaohongshu-primary text-xiaohongshu-primary rounded-full font-medium">
            加入购物车
          </button>
          <button className="flex-1 py-3 xiaohongshu-button font-medium">
            立即购买
          </button>
        </div>
      </div>
    </div>
  );
};

export default ProductDetail;