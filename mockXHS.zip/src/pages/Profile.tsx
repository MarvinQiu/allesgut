import React, { useState } from 'react';
import { mockUsers, mockNotes } from '../data/mockData';

const Profile: React.FC = () => {
  const [activeTab, setActiveTab] = useState('笔记');
  const user = mockUsers[0];
  const userNotes = mockNotes.filter(note => note.author.id === user.id);

  const tabs = ['笔记', '收藏', '赞过'];

  return (
    <div className="min-h-screen bg-xiaohongshu-background">
      {/* 用户信息 */}
      <div className="bg-white px-4 py-6">
        <div className="flex items-start space-x-4">
          <img
            src={user.avatar}
            alt={user.name}
            className="w-20 h-20 avatar"
          />
          
          <div className="flex-1">
            <div className="flex items-center space-x-2 mb-2">
              <h2 className="text-xiaohongshu-text-primary font-bold text-lg">
                {user.name}
              </h2>
              {user.verified && (
                <div className="w-4 h-4 bg-xiaohongshu-primary rounded-full flex items-center justify-center">
                  <svg className="w-2.5 h-2.5 text-white" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                  </svg>
                </div>
              )}
            </div>
            
            <p className="text-xiaohongshu-text-secondary text-sm mb-3">
              {user.bio}
            </p>
            
            <div className="flex space-x-6 text-sm">
              <div className="text-center">
                <div className="text-xiaohongshu-text-primary font-bold">{user.followers}</div>
                <div className="text-xiaohongshu-text-light">粉丝</div>
              </div>
              <div className="text-center">
                <div className="text-xiaohongshu-text-primary font-bold">{user.following}</div>
                <div className="text-xiaohongshu-text-light">关注</div>
              </div>
              <div className="text-center">
                <div className="text-xiaohongshu-text-primary font-bold">{user.likes}</div>
                <div className="text-xiaohongshu-text-light">获赞</div>
              </div>
            </div>
          </div>
        </div>
        
        {/* 操作按钮 */}
        <div className="flex space-x-3 mt-4">
          <button className="flex-1 xiaohongshu-button py-2 text-sm">
            编辑资料
          </button>
          <button className="px-4 py-2 border border-xiaohongshu-border rounded-full text-xiaohongshu-text-secondary text-sm">
            分享主页
          </button>
        </div>
      </div>

      {/* 标签切换 */}
      <div className="bg-white px-4 py-3 border-b border-xiaohongshu-border">
        <div className="flex space-x-6">
          {tabs.map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`pb-2 text-sm font-medium transition-colors relative ${
                activeTab === tab 
                  ? 'text-xiaohongshu-primary' 
                  : 'text-xiaohongshu-text-secondary'
              }`}
            >
              {tab}
              {activeTab === tab && (
                <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-xiaohongshu-primary rounded-full"></div>
              )}
            </button>
          ))}
        </div>
      </div>

      {/* 内容网格 */}
      <div className="p-4">
        {activeTab === '笔记' && (
          <div className="grid grid-cols-2 gap-2">
            {userNotes.map((note) => (
              <div key={note.id} className="xiaohongshu-card overflow-hidden">
                <img
                  src={note.images[0]}
                  alt={note.title}
                  className="w-full h-32 object-cover"
                />
                <div className="p-2">
                  <h4 className="text-xiaohongshu-text-primary text-xs font-medium line-clamp-2">
                    {note.title}
                  </h4>
                  <div className="flex items-center justify-between mt-2">
                    <span className="text-xiaohongshu-text-light text-xs">
                      {note.likes} 赞
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
        
        {activeTab !== '笔记' && (
          <div className="flex flex-col items-center justify-center py-20">
            <div className="text-6xl mb-4">📝</div>
            <p className="text-xiaohongshu-text-light text-sm">暂无内容</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default Profile;