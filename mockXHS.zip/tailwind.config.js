/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./src/**/*.{js,jsx,ts,tsx}",
    "./index.html"
  ],
  theme: {
    extend: {
      colors: {
        xiaohongshu: {
          primary: '#FF2442',
          secondary: '#FF6B7A',
          background: '#FAFAFA',
          card: '#FFFFFF',
          text: {
            primary: '#333333',
            secondary: '#666666',
            light: '#999999'
          },
          border: '#E5E5E5',
          gray: {
            50: '#F8F8F8',
            100: '#F0F0F0',
            200: '#E5E5E5',
            300: '#D4D4D4',
            400: '#A3A3A3',
            500: '#737373',
            600: '#525252',
            700: '#404040',
            800: '#262626',
            900: '#171717'
          }
        }
      },
      fontFamily: {
        'xiaohongshu': ['-apple-system', 'BlinkMacSystemFont', 'Helvetica Neue', 'PingFang SC', 'Hiragino Sans GB', 'Microsoft YaHei UI', 'Microsoft YaHei', 'Arial', 'sans-serif']
      },
      spacing: {
        '18': '4.5rem',
        '88': '22rem'
      },
      borderRadius: {
        'xiaohongshu': '12px'
      },
      boxShadow: {
        'xiaohongshu': '0 2px 8px rgba(0, 0, 0, 0.06)',
        'xiaohongshu-hover': '0 4px 16px rgba(0, 0, 0, 0.12)'
      }
    },
  },
  plugins: [],
};