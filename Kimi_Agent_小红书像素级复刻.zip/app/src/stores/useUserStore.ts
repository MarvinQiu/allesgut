import { create } from 'zustand';
import type { User } from '@/types';
import { currentUser } from '@/data/mockData';

interface UserState {
  // 当前用户
  user: User | null;
  isLoggedIn: boolean;
  
  // 用户操作
  setUser: (user: User) => void;
  logout: () => void;
  
  // 统计数据
  followers: number;
  following: number;
  likes: number;
  
  // 关注操作
  followUser: (userId: string) => void;
  unfollowUser: (userId: string) => void;
  followedUsers: string[];
  
  // 通知数量
  unreadNotifications: number;
  setUnreadNotifications: (count: number) => void;
}

export const useUserStore = create<UserState>((set) => ({
  user: currentUser,
  isLoggedIn: true,
  
  followers: currentUser.followers,
  following: currentUser.following,
  likes: currentUser.likes,
  
  setUser: (user) => set({ user, isLoggedIn: true }),
  logout: () => set({ user: null, isLoggedIn: false }),
  
  followedUsers: [],
  followUser: (userId) => set((state) => ({
    followedUsers: [...state.followedUsers, userId],
    following: state.following + 1,
  })),
  unfollowUser: (userId) => set((state) => ({
    followedUsers: state.followedUsers.filter(id => id !== userId),
    following: state.following - 1,
  })),
  
  unreadNotifications: 5,
  setUnreadNotifications: (count) => set({ unreadNotifications: count }),
}));
