import { create } from 'zustand';
import type { Note } from '@/types';
import { mockNotes } from '@/data/mockData';

interface NoteState {
  // 笔记列表
  notes: Note[];
  
  // 当前查看的笔记
  currentNote: Note | null;
  setCurrentNote: (note: Note | null) => void;
  
  // 点赞相关
  likedNotes: string[];
  likeNote: (id: string) => void;
  unlikeNote: (id: string) => void;
  
  // 收藏相关
  collectedNotes: string[];
  collectNote: (id: string) => void;
  uncollectNote: (id: string) => void;
  
  // 笔记操作
  fetchNotes: () => Promise<void>;
  fetchNotesByCategory: (category: string) => Promise<void>;
  
  // 评论相关
  comments: Record<string, Comment[]>;
  addComment: (noteId: string, content: string) => void;
}

export const useNoteStore = create<NoteState>((set) => ({
  notes: mockNotes,
  currentNote: null,
  setCurrentNote: (note) => set({ currentNote: note }),
  
  likedNotes: [],
  likeNote: (id) => set((state) => {
    const note = state.notes.find(n => n.id === id);
    if (note) {
      note.likes += 1;
      note.isLiked = true;
    }
    return { likedNotes: [...state.likedNotes, id] };
  }),
  unlikeNote: (id) => set((state) => {
    const note = state.notes.find(n => n.id === id);
    if (note) {
      note.likes -= 1;
      note.isLiked = false;
    }
    return { likedNotes: state.likedNotes.filter(noteId => noteId !== id) };
  }),
  
  collectedNotes: [],
  collectNote: (id) => set((state) => {
    const note = state.notes.find(n => n.id === id);
    if (note) {
      note.collects += 1;
      note.isCollected = true;
    }
    return { collectedNotes: [...state.collectedNotes, id] };
  }),
  uncollectNote: (id) => set((state) => {
    const note = state.notes.find(n => n.id === id);
    if (note) {
      note.collects -= 1;
      note.isCollected = false;
    }
    return { collectedNotes: state.collectedNotes.filter(noteId => noteId !== id) };
  }),
  
  fetchNotes: async () => {
    // 模拟API调用
    set({ notes: mockNotes });
  },
  
  fetchNotesByCategory: async (category) => {
    if (category === 'all') {
      set({ notes: mockNotes });
    } else {
      const filtered = mockNotes.filter(note => note.category === category);
      set({ notes: filtered });
    }
  },
  
  comments: {},
  addComment: (noteId, content) => {
    // 模拟添加评论
    console.log('Add comment:', noteId, content);
  },
}));
