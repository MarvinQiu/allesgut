import { create } from 'zustand';
import type { TabType, Category } from '@/types';
import { categories } from '@/data/mockData';

interface AppState {
  // 当前选中的Tab
  currentTab: TabType;
  setCurrentTab: (tab: TabType) => void;
  
  // 搜索相关
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  searchHistory: string[];
  addSearchHistory: (keyword: string) => void;
  clearSearchHistory: () => void;
  
  // 分类相关
  selectedCategory: string;
  setSelectedCategory: (category: string) => void;
  categories: Category[];
  
  // 加载状态
  isLoading: boolean;
  setIsLoading: (loading: boolean) => void;
  
  // 页面滚动位置
  scrollPosition: number;
  setScrollPosition: (position: number) => void;
}

export const useAppStore = create<AppState>((set) => ({
  currentTab: 'home',
  setCurrentTab: (tab) => set({ currentTab: tab }),
  
  searchQuery: '',
  setSearchQuery: (query) => set({ searchQuery: query }),
  searchHistory: ['如何减肥', '上海美食', '穿搭技巧'],
  addSearchHistory: (keyword) => set((state) => ({
    searchHistory: [keyword, ...state.searchHistory.filter(k => k !== keyword)].slice(0, 10)
  })),
  clearSearchHistory: () => set({ searchHistory: [] }),
  
  selectedCategory: 'all',
  setSelectedCategory: (category) => set({ selectedCategory: category }),
  categories,
  
  isLoading: false,
  setIsLoading: (loading) => set({ isLoading: loading }),
  
  scrollPosition: 0,
  setScrollPosition: (position) => set({ scrollPosition: position }),
}));
