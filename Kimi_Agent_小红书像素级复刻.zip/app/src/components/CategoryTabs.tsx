import { motion } from 'framer-motion';
import { useAppStore } from '@/stores/useAppStore';
import { cn } from '@/lib/utils';

export function CategoryTabs() {
  const { categories, selectedCategory, setSelectedCategory } = useAppStore();

  return (
    <div className="sticky top-0 z-40 bg-white border-b border-gray-100">
      <div className="flex items-center gap-1 px-2 py-2 overflow-x-auto scrollbar-hide">
        {categories.map((category) => {
          const isActive = selectedCategory === category.id;
          return (
            <motion.button
              key={category.id}
              onClick={() => setSelectedCategory(category.id)}
              className={cn(
                'relative px-3 py-1.5 text-sm font-medium whitespace-nowrap rounded-full transition-colors duration-200',
                isActive
                  ? 'text-[#FF2442]'
                  : 'text-gray-600 hover:text-gray-900'
              )}
              whileTap={{ scale: 0.95 }}
            >
              {category.name}
              {isActive && (
                <motion.div
                  layoutId="categoryIndicator"
                  className="absolute bottom-0 left-1/2 -translate-x-1/2 w-4 h-0.5 bg-[#FF2442] rounded-full"
                  transition={{ type: 'spring', stiffness: 500, damping: 30 }}
                />
              )}
            </motion.button>
          );
        })}
      </div>
    </div>
  );
}
