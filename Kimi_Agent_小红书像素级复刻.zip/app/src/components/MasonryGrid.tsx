import { useEffect, useRef, useState } from 'react';
import type { Note } from '@/types';
import { NoteCard } from './NoteCard';

interface MasonryGridProps {
  notes: Note[];
  onNoteClick?: (note: Note) => void;
}

export function MasonryGrid({ notes, onNoteClick }: MasonryGridProps) {
  const [columns, setColumns] = useState<Note[][]>([[], []]);
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // 将笔记分配到两列，保持瀑布流效果
    const leftColumn: Note[] = [];
    const rightColumn: Note[] = [];
    
    notes.forEach((note, index) => {
      if (index % 2 === 0) {
        leftColumn.push(note);
      } else {
        rightColumn.push(note);
      }
    });
    
    setColumns([leftColumn, rightColumn]);
  }, [notes]);

  return (
    <div ref={containerRef} className="px-2 py-2">
      <div className="flex gap-2">
        {columns.map((column, columnIndex) => (
          <div key={columnIndex} className="flex-1 flex flex-col gap-2">
            {column.map((note, noteIndex) => (
              <NoteCard
                key={note.id}
                note={note}
                onClick={onNoteClick}
                index={columnIndex * 2 + noteIndex}
              />
            ))}
          </div>
        ))}
      </div>
    </div>
  );
}
