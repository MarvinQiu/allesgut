import { motion } from 'framer-motion';
import { ChevronLeft, Settings, Share2 } from 'lucide-react';
import type { User } from '@/types';
import { cn } from '@/lib/utils';
import { useUserStore } from '@/stores/useUserStore';

interface UserHeaderProps {
  user: User;
  onBack?: () => void;
  className?: string;
}

export function UserHeader({ user, onBack, className }: UserHeaderProps) {
  const { followedUsers, followUser, unfollowUser } = useUserStore();
  const isFollowing = followedUsers.includes(user.id);

  const handleFollow = () => {
    if (isFollowing) {
      unfollowUser(user.id);
    } else {
      followUser(user.id);
    }
  };

  const formatNumber = (num: number): string => {
    if (num >= 10000) {
      return (num / 10000).toFixed(1) + '万';
    }
    return num.toLocaleString();
  };

  return (
    <div className={cn('bg-white', className)}>
      {/* 顶部导航 */}
      <div className="flex items-center justify-between px-4 py-3">
        <motion.button
          whileTap={{ scale: 0.9 }}
          onClick={onBack}
          className="p-1"
        >
          <ChevronLeft className="w-6 h-6 text-gray-800" />
        </motion.button>
        <div className="flex items-center gap-3">
          <motion.button whileTap={{ scale: 0.9 }} className="p-1">
            <Share2 className="w-5 h-5 text-gray-800" />
          </motion.button>
          <motion.button whileTap={{ scale: 0.9 }} className="p-1">
            <Settings className="w-5 h-5 text-gray-800" />
          </motion.button>
        </div>
      </div>

      {/* 用户信息 */}
      <div className="px-4 pb-4">
        <div className="flex items-start gap-4">
          {/* 头像 */}
          <div className="relative">
            <img
              src={user.avatar}
              alt={user.username}
              className="w-20 h-20 rounded-full object-cover border-2 border-gray-100"
            />
            {user.isVerified && (
              <div className="absolute -bottom-1 -right-1 w-6 h-6 bg-[#FF2442] rounded-full flex items-center justify-center">
                <span className="text-white text-xs">✓</span>
              </div>
            )}
          </div>

          {/* 基本信息 */}
          <div className="flex-1 pt-1">
            <div className="flex items-center gap-2">
              <h1 className="text-lg font-semibold text-gray-900">{user.username}</h1>
              {user.isVerified && (
                <span className="px-1.5 py-0.5 bg-[#FF2442]/10 text-[#FF2442] text-[10px] rounded">
                  认证用户
                </span>
              )}
            </div>
            <p className="text-xs text-gray-500 mt-0.5">小红书号：{user.id}</p>
          </div>
        </div>

        {/* 个人简介 */}
        {user.bio && (
          <p className="mt-3 text-sm text-gray-700 whitespace-pre-line">{user.bio}</p>
        )}

        {/* 位置 */}
        {user.location && (
          <p className="mt-2 text-xs text-gray-500">📍 {user.location}</p>
        )}

        {/* 统计数据 */}
        <div className="flex items-center gap-6 mt-4">
          <div className="text-center">
            <p className="text-base font-semibold text-gray-900">{formatNumber(user.following)}</p>
            <p className="text-xs text-gray-500">关注</p>
          </div>
          <div className="text-center">
            <p className="text-base font-semibold text-gray-900">{formatNumber(user.followers)}</p>
            <p className="text-xs text-gray-500">粉丝</p>
          </div>
          <div className="text-center">
            <p className="text-base font-semibold text-gray-900">{formatNumber(user.likes)}</p>
            <p className="text-xs text-gray-500">获赞与收藏</p>
          </div>
        </div>

        {/* 操作按钮 */}
        <div className="flex gap-3 mt-4">
          <motion.button
            whileTap={{ scale: 0.95 }}
            onClick={handleFollow}
            className={cn(
              'flex-1 py-2 rounded-full text-sm font-medium transition-colors',
              isFollowing
                ? 'bg-gray-100 text-gray-700'
                : 'bg-[#FF2442] text-white'
            )}
          >
            {isFollowing ? '已关注' : '关注'}
          </motion.button>
          <motion.button
            whileTap={{ scale: 0.95 }}
            className="flex-1 py-2 bg-gray-100 text-gray-700 rounded-full text-sm font-medium"
          >
            私信
          </motion.button>
        </div>
      </div>
    </div>
  );
}
