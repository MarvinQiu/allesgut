import { motion } from 'framer-motion';
import { Home, ShoppingBag, MessageCircle, User, Plus } from 'lucide-react';
import type { TabType } from '@/types';
import { useAppStore } from '@/stores/useAppStore';
import { useUserStore } from '@/stores/useUserStore';
import { cn } from '@/lib/utils';

interface NavItem {
  id: TabType;
  icon: React.ElementType;
  label: string;
  isCenter?: boolean;
}

const navItems: NavItem[] = [
  { id: 'home', icon: Home, label: '首页' },
  { id: 'shopping', icon: ShoppingBag, label: '购物' },
  { id: 'publish', icon: Plus, label: '', isCenter: true },
  { id: 'message', icon: MessageCircle, label: '消息' },
  { id: 'profile', icon: User, label: '我' },
];

export function BottomNav() {
  const { currentTab, setCurrentTab } = useAppStore();
  const { unreadNotifications } = useUserStore();

  const handleTabClick = (tabId: TabType) => {
    if (tabId === 'publish') {
      // 处理发布逻辑
      console.log('Open publish modal');
      return;
    }
    setCurrentTab(tabId);
  };

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-50 bg-white border-t border-gray-200 pb-safe">
      <div className="flex items-center justify-around h-14">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = currentTab === item.id && !item.isCenter;
          
          if (item.isCenter) {
            return (
              <motion.button
                key={item.id}
                whileTap={{ scale: 0.95 }}
                onClick={() => handleTabClick(item.id)}
                className="relative -top-3 flex items-center justify-center w-12 h-12 bg-[#FF2442] rounded-xl shadow-lg shadow-red-200"
              >
                <Icon className="w-6 h-6 text-white" strokeWidth={2.5} />
              </motion.button>
            );
          }

          return (
            <motion.button
              key={item.id}
              whileTap={{ scale: 0.9 }}
              onClick={() => handleTabClick(item.id)}
              className="flex flex-col items-center justify-center flex-1 h-full relative"
            >
              <div className="relative">
                <Icon
                  className={cn(
                    'w-6 h-6 transition-colors duration-200',
                    isActive ? 'text-[#FF2442]' : 'text-gray-500'
                  )}
                  strokeWidth={isActive ? 2.5 : 2}
                />
                {item.id === 'message' && unreadNotifications > 0 && (
                  <span className="absolute -top-1 -right-1 w-4 h-4 bg-[#FF2442] text-white text-[10px] font-medium rounded-full flex items-center justify-center">
                    {unreadNotifications > 99 ? '99+' : unreadNotifications}
                  </span>
                )}
              </div>
              <span
                className={cn(
                  'text-[10px] mt-0.5 transition-colors duration-200',
                  isActive ? 'text-[#FF2442]' : 'text-gray-500'
                )}
              >
                {item.label}
              </span>
              {isActive && (
                <motion.div
                  layoutId="bottomNavIndicator"
                  className="absolute bottom-1 w-1 h-1 bg-[#FF2442] rounded-full"
                  transition={{ type: 'spring', stiffness: 500, damping: 30 }}
                />
              )}
            </motion.button>
          );
        })}
      </div>
    </nav>
  );
}
