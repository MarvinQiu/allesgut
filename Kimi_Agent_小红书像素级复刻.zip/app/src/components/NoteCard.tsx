import { motion } from 'framer-motion';
import { Heart, MessageCircle, Play } from 'lucide-react';
import type { Note } from '@/types';

interface NoteCardProps {
  note: Note;
  onClick?: (note: Note) => void;
  index?: number;
}

export function NoteCard({ note, onClick, index = 0 }: NoteCardProps) {
  const formatNumber = (num: number): string => {
    if (num >= 10000) {
      return (num / 10000).toFixed(1) + '万';
    }
    return num.toLocaleString();
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ 
        duration: 0.3, 
        delay: index * 0.05,
        ease: [0.4, 0, 0.2, 1]
      }}
      whileHover={{ y: -4 }}
      onClick={() => onClick?.(note)}
      className="bg-white rounded-lg overflow-hidden shadow-sm hover:shadow-md transition-shadow duration-200 cursor-pointer"
    >
      {/* 封面图片 */}
      <div className="relative aspect-[3/4] overflow-hidden">
        <img
          src={note.coverImage}
          alt={note.title}
          className="w-full h-full object-cover"
          loading="lazy"
        />
        {note.isVideo && (
          <div className="absolute bottom-2 right-2 w-6 h-6 bg-black/50 rounded-full flex items-center justify-center">
            <Play className="w-3 h-3 text-white fill-white" />
          </div>
        )}
      </div>

      {/* 内容区域 */}
      <div className="p-2.5">
        {/* 标题 */}
        <h3 className="text-sm font-medium text-gray-900 line-clamp-2 leading-snug mb-2">
          {note.title}
        </h3>

        {/* 作者信息 */}
        <div className="flex items-center gap-1.5 mb-2">
          <img
            src={note.author.avatar}
            alt={note.author.username}
            className="w-4 h-4 rounded-full object-cover"
          />
          <span className="text-xs text-gray-500 truncate">
            {note.author.username}
          </span>
        </div>

        {/* 互动数据 */}
        <div className="flex items-center justify-between text-xs text-gray-400">
          <div className="flex items-center gap-3">
            <span className="flex items-center gap-1">
              <Heart className="w-3.5 h-3.5" />
              {formatNumber(note.likes)}
            </span>
            <span className="flex items-center gap-1">
              <MessageCircle className="w-3.5 h-3.5" />
              {formatNumber(note.comments)}
            </span>
          </div>
        </div>
      </div>
    </motion.div>
  );
}
