import { motion } from 'framer-motion';
import { MessageCircle, Share2 } from 'lucide-react';
import type { Note } from '@/types';
import { LikeButton } from './LikeButton';
import { CollectButton } from './CollectButton';
import { useNoteStore } from '@/stores/useNoteStore';

interface ActionBarProps {
  note: Note;
  orientation?: 'vertical' | 'horizontal';
  className?: string;
}

export function ActionBar({ 
  note, 
  orientation = 'vertical',
  className 
}: ActionBarProps) {
  const { likedNotes, collectedNotes, likeNote, unlikeNote, collectNote, uncollectNote } = useNoteStore();
  
  const isLiked = likedNotes.includes(note.id) || note.isLiked || false;
  const isCollected = collectedNotes.includes(note.id) || note.isCollected || false;

  const handleLike = () => {
    if (isLiked) {
      unlikeNote(note.id);
    } else {
      likeNote(note.id);
    }
  };

  const handleCollect = () => {
    if (isCollected) {
      uncollectNote(note.id);
    } else {
      collectNote(note.id);
    }
  };

  const formatNumber = (num: number): string => {
    if (num >= 10000) {
      return (num / 10000).toFixed(1) + '万';
    }
    return num.toLocaleString();
  };

  if (orientation === 'horizontal') {
    return (
      <div className={`flex items-center gap-4 ${className}`}>
        <LikeButton
          isLiked={isLiked}
          count={note.likes}
          onClick={handleLike}
          size="md"
        />
        <CollectButton
          isCollected={isCollected}
          count={note.collects}
          onClick={handleCollect}
          size="md"
        />
        <motion.button
          whileTap={{ scale: 0.9 }}
          className="flex flex-col items-center gap-1"
        >
          <MessageCircle className="w-6 h-6 text-gray-600" />
          <span className="text-xs text-gray-600">{formatNumber(note.comments)}</span>
        </motion.button>
        <motion.button
          whileTap={{ scale: 0.9 }}
          className="flex flex-col items-center gap-1"
        >
          <Share2 className="w-6 h-6 text-gray-600" />
          <span className="text-xs text-gray-600">分享</span>
        </motion.button>
      </div>
    );
  }

  return (
    <div className={`flex flex-col items-center gap-4 ${className}`}>
      {/* 用户头像 */}
      <motion.div 
        className="relative"
        whileTap={{ scale: 0.95 }}
      >
        <img
          src={note.author.avatar}
          alt={note.author.username}
          className="w-12 h-12 rounded-full border-2 border-white object-cover"
        />
        <div className="absolute -bottom-1 -right-1 w-5 h-5 bg-[#FF2442] rounded-full flex items-center justify-center">
          <span className="text-white text-xs">+</span>
        </div>
      </motion.div>

      {/* 点赞按钮 */}
      <LikeButton
        isLiked={isLiked}
        count={note.likes}
        onClick={handleLike}
        size="lg"
      />

      {/* 收藏按钮 */}
      <CollectButton
        isCollected={isCollected}
        count={note.collects}
        onClick={handleCollect}
        size="lg"
      />

      {/* 评论按钮 */}
      <motion.button
        whileTap={{ scale: 0.9 }}
        className="flex flex-col items-center gap-1"
      >
        <MessageCircle className="w-8 h-8 text-white fill-white/80" />
        <span className="text-xs text-white/80 font-medium">{formatNumber(note.comments)}</span>
      </motion.button>

      {/* 分享按钮 */}
      <motion.button
        whileTap={{ scale: 0.9 }}
        className="flex flex-col items-center gap-1"
      >
        <Share2 className="w-8 h-8 text-white fill-white/80" />
        <span className="text-xs text-white/80 font-medium">分享</span>
      </motion.button>
    </div>
  );
}
