import { motion, AnimatePresence } from 'framer-motion';
import { Star } from 'lucide-react';
import { cn } from '@/lib/utils';

interface CollectButtonProps {
  isCollected: boolean;
  count: number;
  onClick: () => void;
  size?: 'sm' | 'md' | 'lg';
  showCount?: boolean;
  className?: string;
}

export function CollectButton({
  isCollected,
  count,
  onClick,
  size = 'md',
  showCount = true,
  className,
}: CollectButtonProps) {
  const sizeClasses = {
    sm: 'w-4 h-4',
    md: 'w-6 h-6',
    lg: 'w-8 h-8',
  };

  const formatNumber = (num: number): string => {
    if (num >= 10000) {
      return (num / 10000).toFixed(1) + '万';
    }
    return num.toLocaleString();
  };

  return (
    <motion.button
      onClick={onClick}
      className={cn(
        'flex flex-col items-center gap-1 transition-colors',
        className
      )}
      whileTap={{ scale: 0.9 }}
    >
      <div className="relative">
        <AnimatePresence mode="wait">
          <motion.div
            key={isCollected ? 'collected' : 'uncollected'}
            initial={{ scale: 0, rotate: 0, opacity: 0 }}
            animate={{ 
              scale: isCollected ? [1, 1.2, 1] : 1,
              rotate: isCollected ? [0, 72, 0] : 0,
              opacity: 1 
            }}
            exit={{ scale: 0, opacity: 0 }}
            transition={{ 
              duration: 0.4,
              ease: isCollected ? [0.34, 1.56, 0.64, 1] : 'easeOut'
            }}
          >
            <Star
              className={cn(
                sizeClasses[size],
                isCollected 
                  ? 'text-[#FFB800] fill-[#FFB800]' 
                  : 'text-white fill-white/80'
              )}
              strokeWidth={2}
            />
          </motion.div>
        </AnimatePresence>
      </div>
      
      {showCount && (
        <span className={cn(
          'text-xs font-medium',
          isCollected ? 'text-[#FFB800]' : 'text-white/80'
        )}>
          {formatNumber(count)}
        </span>
      )}
    </motion.button>
  );
}
