import { motion, AnimatePresence } from 'framer-motion';
import { Heart } from 'lucide-react';
import { cn } from '@/lib/utils';

interface LikeButtonProps {
  isLiked: boolean;
  count: number;
  onClick: () => void;
  size?: 'sm' | 'md' | 'lg';
  showCount?: boolean;
  className?: string;
}

export function LikeButton({
  isLiked,
  count,
  onClick,
  size = 'md',
  showCount = true,
  className,
}: LikeButtonProps) {
  const sizeClasses = {
    sm: 'w-4 h-4',
    md: 'w-6 h-6',
    lg: 'w-8 h-8',
  };

  const formatNumber = (num: number): string => {
    if (num >= 10000) {
      return (num / 10000).toFixed(1) + '万';
    }
    return num.toLocaleString();
  };

  return (
    <motion.button
      onClick={onClick}
      className={cn(
        'flex flex-col items-center gap-1 transition-colors',
        className
      )}
      whileTap={{ scale: 0.9 }}
    >
      <div className="relative">
        <AnimatePresence mode="wait">
          <motion.div
            key={isLiked ? 'liked' : 'unliked'}
            initial={{ scale: 0, opacity: 0 }}
            animate={{ 
              scale: isLiked ? [1, 1.3, 1] : 1, 
              opacity: 1 
            }}
            exit={{ scale: 0, opacity: 0 }}
            transition={{ 
              duration: 0.3,
              ease: isLiked ? [0.34, 1.56, 0.64, 1] : 'easeOut'
            }}
          >
            <Heart
              className={cn(
                sizeClasses[size],
                isLiked 
                  ? 'text-[#FF2442] fill-[#FF2442]' 
                  : 'text-white fill-white/80'
              )}
              strokeWidth={2}
            />
          </motion.div>
        </AnimatePresence>
        
        {/* 点赞时的粒子效果 */}
        <AnimatePresence>
          {isLiked && (
            <>
              {[...Array(6)].map((_, i) => (
                <motion.div
                  key={i}
                  className="absolute top-1/2 left-1/2 w-1 h-1 bg-[#FF2442] rounded-full"
                  initial={{ x: '-50%', y: '-50%', scale: 0, opacity: 1 }}
                  animate={{
                    x: `${Math.cos((i * 60 * Math.PI) / 180) * 20 - 50}%`,
                    y: `${Math.sin((i * 60 * Math.PI) / 180) * 20 - 50}%`,
                    scale: [0, 1, 0],
                    opacity: [1, 1, 0],
                  }}
                  exit={{ opacity: 0 }}
                  transition={{ duration: 0.5, ease: 'easeOut' }}
                />
              ))}
            </>
          )}
        </AnimatePresence>
      </div>
      
      {showCount && (
        <span className={cn(
          'text-xs font-medium',
          isLiked ? 'text-[#FF2442]' : 'text-white/80'
        )}>
          {formatNumber(count)}
        </span>
      )}
    </motion.button>
  );
}
