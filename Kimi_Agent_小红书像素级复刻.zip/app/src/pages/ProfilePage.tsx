import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { UserHeader } from '@/components/UserHeader';
import { MasonryGrid } from '@/components/MasonryGrid';
import { useUserStore } from '@/stores/useUserStore';
import { useNoteStore } from '@/stores/useNoteStore';
import type { Note } from '@/types';
import { cn } from '@/lib/utils';

interface ProfilePageProps {
  onNoteClick?: (note: Note) => void;
  onBack?: () => void;
}

type TabType = 'notes' | 'collections';

export function ProfilePage({ onNoteClick, onBack }: ProfilePageProps) {
  const { user } = useUserStore();
  const { notes } = useNoteStore();
  const [activeTab, setActiveTab] = useState<TabType>('notes');

  if (!user) {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center">
        <p className="text-gray-500">请先登录</p>
      </div>
    );
  }

  // 过滤当前用户的笔记
  const userNotes = notes.filter(note => note.author.id === user.id);
  
  // 收藏的笔记（模拟）
  const collectedNotes = notes.slice(0, 4);

  const displayNotes = activeTab === 'notes' ? userNotes : collectedNotes;

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="min-h-screen bg-gray-50 pb-20"
    >
      {/* 用户头部 */}
      <UserHeader user={user} onBack={onBack} />

      {/* 内容标签 */}
      <div className="sticky top-0 z-40 bg-white border-b border-gray-100">
        <div className="flex">
          <motion.button
            whileTap={{ scale: 0.98 }}
            onClick={() => setActiveTab('notes')}
            className={cn(
              'flex-1 py-3 text-sm font-medium relative',
              activeTab === 'notes' ? 'text-gray-900' : 'text-gray-500'
            )}
          >
            笔记
            <span className="ml-1 text-xs text-gray-400">{userNotes.length}</span>
            {activeTab === 'notes' && (
              <motion.div
                layoutId="profileTabIndicator"
                className="absolute bottom-0 left-1/2 -translate-x-1/2 w-8 h-0.5 bg-[#FF2442] rounded-full"
                transition={{ type: 'spring', stiffness: 500, damping: 30 }}
              />
            )}
          </motion.button>
          <motion.button
            whileTap={{ scale: 0.98 }}
            onClick={() => setActiveTab('collections')}
            className={cn(
              'flex-1 py-3 text-sm font-medium relative',
              activeTab === 'collections' ? 'text-gray-900' : 'text-gray-500'
            )}
          >
            收藏
            <span className="ml-1 text-xs text-gray-400">{collectedNotes.length}</span>
            {activeTab === 'collections' && (
              <motion.div
                layoutId="profileTabIndicator"
                className="absolute bottom-0 left-1/2 -translate-x-1/2 w-8 h-0.5 bg-[#FF2442] rounded-full"
                transition={{ type: 'spring', stiffness: 500, damping: 30 }}
              />
            )}
          </motion.button>
        </div>
      </div>

      {/* 内容区域 */}
      <AnimatePresence mode="wait">
        <motion.div
          key={activeTab}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -10 }}
          transition={{ duration: 0.2 }}
        >
          {displayNotes.length > 0 ? (
            <MasonryGrid notes={displayNotes} onNoteClick={onNoteClick} />
          ) : (
            <div className="flex flex-col items-center justify-center py-20">
              <div className="w-20 h-20 bg-gray-100 rounded-full flex items-center justify-center mb-4">
                <span className="text-4xl">📝</span>
              </div>
              <p className="text-gray-500 text-sm">
                {activeTab === 'notes' ? '还没有发布笔记' : '还没有收藏内容'}
              </p>
              {activeTab === 'notes' && (
                <motion.button
                  whileTap={{ scale: 0.95 }}
                  className="mt-4 px-6 py-2 bg-[#FF2442] text-white text-sm font-medium rounded-full"
                >
                  去发布
                </motion.button>
              )}
            </div>
          )}
        </motion.div>
      </AnimatePresence>
    </motion.div>
  );
}
