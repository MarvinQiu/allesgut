import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronLeft, Clock, TrendingUp, X } from 'lucide-react';
import { SearchBar } from '@/components/SearchBar';
import { useAppStore } from '@/stores/useAppStore';
import { hotSearches } from '@/data/mockData';
import { cn } from '@/lib/utils';

interface SearchPageProps {
  onBack?: () => void;
}

export function SearchPage({ onBack }: SearchPageProps) {
  const { searchQuery, setSearchQuery, searchHistory, addSearchHistory, clearSearchHistory } = useAppStore();
  const [showResults, setShowResults] = useState(false);

  const handleSearch = (query: string) => {
    if (query.trim()) {
      addSearchHistory(query);
      setShowResults(true);
    }
  };

  const handleHistoryClick = (keyword: string) => {
    setSearchQuery(keyword);
    handleSearch(keyword);
  };

  const handleClearHistory = () => {
    clearSearchHistory();
  };

  return (
    <motion.div
      initial={{ opacity: 0, x: '100%' }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: '100%' }}
      transition={{ type: 'spring', damping: 25, stiffness: 200 }}
      className="min-h-screen bg-white"
    >
      {/* 顶部搜索栏 */}
      <div className="flex items-center gap-3 px-4 py-3 border-b border-gray-100">
        <motion.button
          whileTap={{ scale: 0.9 }}
          onClick={onBack}
          className="p-1"
        >
          <ChevronLeft className="w-6 h-6 text-gray-700" />
        </motion.button>
        <div className="flex-1">
          <SearchBar
            value={searchQuery}
            onChange={setSearchQuery}
            onSearch={handleSearch}
            placeholder="搜索笔记、用户、话题..."
          />
        </div>
        <motion.button
          whileTap={{ scale: 0.9 }}
          onClick={() => handleSearch(searchQuery)}
          className="text-[#FF2442] font-medium"
        >
          搜索
        </motion.button>
      </div>

      <AnimatePresence mode="wait">
        {!showResults ? (
          <motion.div
            key="search-suggestions"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="p-4"
          >
            {/* 搜索历史 */}
            {searchHistory.length > 0 && (
              <div className="mb-6">
                <div className="flex items-center justify-between mb-3">
                  <h3 className="text-sm font-medium text-gray-900">历史搜索</h3>
                  <motion.button
                    whileTap={{ scale: 0.9 }}
                    onClick={handleClearHistory}
                    className="p-1"
                  >
                    <X className="w-4 h-4 text-gray-400" />
                  </motion.button>
                </div>
                <div className="flex flex-wrap gap-2">
                  {searchHistory.map((keyword, index) => (
                    <motion.button
                      key={index}
                      whileTap={{ scale: 0.95 }}
                      onClick={() => handleHistoryClick(keyword)}
                      className="flex items-center gap-1 px-3 py-1.5 bg-gray-100 rounded-full text-sm text-gray-700"
                    >
                      <Clock className="w-3.5 h-3.5 text-gray-400" />
                      {keyword}
                    </motion.button>
                  ))}
                </div>
              </div>
            )}

            {/* 热门搜索 */}
            <div>
              <div className="flex items-center gap-2 mb-3">
                <TrendingUp className="w-4 h-4 text-[#FF2442]" />
                <h3 className="text-sm font-medium text-gray-900">热门搜索</h3>
              </div>
              <div className="space-y-3">
                {hotSearches.map((keyword, index) => (
                  <motion.button
                    key={index}
                    whileTap={{ scale: 0.98 }}
                    onClick={() => handleHistoryClick(keyword)}
                    className="flex items-center gap-3 w-full py-2"
                  >
                    <span className={cn(
                      'w-5 h-5 flex items-center justify-center text-xs font-medium rounded',
                      index < 3 ? 'bg-[#FF2442] text-white' : 'bg-gray-100 text-gray-500'
                    )}>
                      {index + 1}
                    </span>
                    <span className="text-sm text-gray-700">{keyword}</span>
                  </motion.button>
                ))}
              </div>
            </div>
          </motion.div>
        ) : (
          <motion.div
            key="search-results"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="p-4"
          >
            <div className="text-center py-8">
              <p className="text-gray-500">搜索结果：{searchQuery}</p>
              <p className="text-sm text-gray-400 mt-2">找到 128 条相关内容</p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}
