import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronLeft, MoreHorizontal, Share2, Flag, Bookmark } from 'lucide-react';
import type { Note } from '@/types';
import { ActionBar } from '@/components/ActionBar';
import { cn } from '@/lib/utils';

interface NoteDetailPageProps {
  note: Note;
  onBack?: () => void;
}

export function NoteDetailPage({ note, onBack }: NoteDetailPageProps) {
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [showMenu, setShowMenu] = useState(false);

  const formatDate = (dateString: string): string => {
    const date = new Date(dateString);
    return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
  };

  return (
    <motion.div
      initial={{ opacity: 0, x: '100%' }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: '100%' }}
      transition={{ type: 'spring', damping: 25, stiffness: 200 }}
      className="min-h-screen bg-white pb-20"
    >
      {/* 顶部导航 */}
      <div className="sticky top-0 z-50 flex items-center justify-between px-4 py-3 bg-white/80 backdrop-blur-md border-b border-gray-100">
        <motion.button
          whileTap={{ scale: 0.9 }}
          onClick={onBack}
          className="p-1"
        >
          <ChevronLeft className="w-6 h-6 text-gray-800" />
        </motion.button>
        <div className="flex items-center gap-3">
          <motion.button whileTap={{ scale: 0.9 }} className="p-1">
            <Share2 className="w-5 h-5 text-gray-700" />
          </motion.button>
          <motion.button 
            whileTap={{ scale: 0.9 }} 
            className="p-1"
            onClick={() => setShowMenu(!showMenu)}
          >
            <MoreHorizontal className="w-5 h-5 text-gray-700" />
          </motion.button>
        </div>
      </div>

      {/* 图片轮播 */}
      <div className="relative aspect-square bg-gray-100">
        <motion.img
          key={currentImageIndex}
          src={note.images[currentImageIndex] || note.coverImage}
          alt={note.title}
          className="w-full h-full object-cover"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.3 }}
        />
        
        {/* 图片指示器 */}
        {note.images.length > 1 && (
          <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex gap-1.5">
            {note.images.map((_, index) => (
              <button
                key={index}
                onClick={() => setCurrentImageIndex(index)}
                className={cn(
                  'w-1.5 h-1.5 rounded-full transition-all',
                  index === currentImageIndex
                    ? 'bg-white w-4'
                    : 'bg-white/50'
                )}
              />
            ))}
          </div>
        )}

        {/* 图片计数 */}
        {note.images.length > 1 && (
          <div className="absolute top-4 right-4 px-2 py-1 bg-black/50 rounded-full">
            <span className="text-xs text-white">
              {currentImageIndex + 1}/{note.images.length}
            </span>
          </div>
        )}
      </div>

      {/* 内容区域 */}
      <div className="p-4">
        {/* 作者信息 */}
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <img
              src={note.author.avatar}
              alt={note.author.username}
              className="w-10 h-10 rounded-full object-cover"
            />
            <div>
              <p className="text-sm font-medium text-gray-900">{note.author.username}</p>
              <p className="text-xs text-gray-500">{formatDate(note.createdAt)}</p>
            </div>
          </div>
          <motion.button
            whileTap={{ scale: 0.95 }}
            className="px-4 py-1.5 bg-[#FF2442] text-white text-sm font-medium rounded-full"
          >
            关注
          </motion.button>
        </div>

        {/* 标题 */}
        <h1 className="text-lg font-semibold text-gray-900 mb-3">{note.title}</h1>

        {/* 正文内容 */}
        {note.content && (
          <p className="text-sm text-gray-700 leading-relaxed mb-4">{note.content}</p>
        )}

        {/* 话题标签 */}
        {note.tags && note.tags.length > 0 && (
          <div className="flex flex-wrap gap-2 mb-4">
            {note.tags.map((tag, index) => (
              <span
                key={index}
                className="text-sm text-[#3B82F6]"
              >
                #{tag}
              </span>
            ))}
          </div>
        )}

        {/* 位置信息 */}
        {note.location && (
          <p className="text-xs text-gray-500 mb-4">📍 {note.location}</p>
        )}

        {/* 发布时间 */}
        <p className="text-xs text-gray-400">{formatDate(note.createdAt)}</p>
      </div>

      {/* 底部操作栏 */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-100 px-4 py-3 safe-area-bottom">
        <ActionBar note={note} orientation="horizontal" />
      </div>

      {/* 更多菜单 */}
      <AnimatePresence>
        {showMenu && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/50 z-50"
              onClick={() => setShowMenu(false)}
            />
            <motion.div
              initial={{ opacity: 0, y: '100%' }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: '100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 300 }}
              className="fixed bottom-0 left-0 right-0 bg-white rounded-t-2xl z-50 p-4"
            >
              <div className="space-y-2">
                <motion.button
                  whileTap={{ scale: 0.98 }}
                  className="flex items-center gap-3 w-full p-3 rounded-lg hover:bg-gray-50"
                >
                  <Bookmark className="w-5 h-5 text-gray-600" />
                  <span className="text-sm text-gray-700">收藏</span>
                </motion.button>
                <motion.button
                  whileTap={{ scale: 0.98 }}
                  className="flex items-center gap-3 w-full p-3 rounded-lg hover:bg-gray-50"
                >
                  <Share2 className="w-5 h-5 text-gray-600" />
                  <span className="text-sm text-gray-700">分享</span>
                </motion.button>
                <motion.button
                  whileTap={{ scale: 0.98 }}
                  className="flex items-center gap-3 w-full p-3 rounded-lg hover:bg-gray-50"
                >
                  <Flag className="w-5 h-5 text-gray-600" />
                  <span className="text-sm text-gray-700">举报</span>
                </motion.button>
                <motion.button
                  whileTap={{ scale: 0.98 }}
                  onClick={() => setShowMenu(false)}
                  className="w-full p-3 text-center text-sm text-gray-500 border-t border-gray-100 mt-2"
                >
                  取消
                </motion.button>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </motion.div>
  );
}
