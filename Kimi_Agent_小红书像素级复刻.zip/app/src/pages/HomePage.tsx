import { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { Search, Bell } from 'lucide-react';
import { CategoryTabs } from '@/components/CategoryTabs';
import { MasonryGrid } from '@/components/MasonryGrid';
import { SearchBar } from '@/components/SearchBar';
import { useAppStore } from '@/stores/useAppStore';
import { useNoteStore } from '@/stores/useNoteStore';
import { useUserStore } from '@/stores/useUserStore';
import type { Note } from '@/types';

interface HomePageProps {
  onNoteClick?: (note: Note) => void;
  onSearchClick?: () => void;
}

export function HomePage({ onNoteClick, onSearchClick }: HomePageProps) {
  const { selectedCategory } = useAppStore();
  const { notes, fetchNotesByCategory } = useNoteStore();
  const { unreadNotifications } = useUserStore();
  const [isSearchOpen, setIsSearchOpen] = useState(false);

  useEffect(() => {
    fetchNotesByCategory(selectedCategory);
  }, [selectedCategory, fetchNotesByCategory]);

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="min-h-screen bg-gray-50 pb-20"
    >
      {/* 顶部导航 */}
      <div className="sticky top-0 z-50 bg-white border-b border-gray-100">
        <div className="flex items-center justify-between px-4 py-3">
          {/* Logo */}
          <div className="flex items-center">
            <span className="text-xl font-bold text-[#FF2442]">小红书</span>
          </div>

          {/* 搜索和消息 */}
          <div className="flex items-center gap-3">
            {isSearchOpen ? (
              <motion.div
                initial={{ width: 0, opacity: 0 }}
                animate={{ width: 200, opacity: 1 }}
                exit={{ width: 0, opacity: 0 }}
                className="overflow-hidden"
              >
                <SearchBar
                  autoFocus
                  onSearch={() => setIsSearchOpen(false)}
                />
              </motion.div>
            ) : (
              <motion.button
                whileTap={{ scale: 0.9 }}
                onClick={() => onSearchClick?.()}
                className="p-2"
              >
                <Search className="w-5 h-5 text-gray-700" />
              </motion.button>
            )}
            <motion.button
              whileTap={{ scale: 0.9 }}
              className="p-2 relative"
            >
              <Bell className="w-5 h-5 text-gray-700" />
              {unreadNotifications > 0 && (
                <span className="absolute top-1 right-1 w-4 h-4 bg-[#FF2442] text-white text-[10px] font-medium rounded-full flex items-center justify-center">
                  {unreadNotifications > 99 ? '99+' : unreadNotifications}
                </span>
              )}
            </motion.button>
          </div>
        </div>

        {/* 分类标签 */}
        <CategoryTabs />
      </div>

      {/* 瀑布流内容 */}
      <MasonryGrid notes={notes} onNoteClick={onNoteClick} />

      {/* 加载更多提示 */}
      <div className="py-4 text-center">
        <span className="text-sm text-gray-400">正在加载更多...</span>
      </div>
    </motion.div>
  );
}
