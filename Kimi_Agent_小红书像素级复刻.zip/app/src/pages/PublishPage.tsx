import { useState } from 'react';
import { motion } from 'framer-motion';
import { X, Image, Hash, MapPin, AtSign, Smile } from 'lucide-react';
import { cn } from '@/lib/utils';

interface PublishPageProps {
  onClose?: () => void;
}

export function PublishPage({ onClose }: PublishPageProps) {
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [selectedImages, setSelectedImages] = useState<string[]>([]);
  const [selectedTopic, setSelectedTopic] = useState('');

  const topics = ['我的日常', '穿搭', '美食', '旅行', '美妆', '健身', '家居'];

  const handleImageSelect = () => {
    // 模拟选择图片
    const mockImages = [
      'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=200&h=200&fit=crop',
      'https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=200&h=200&fit=crop',
    ];
    setSelectedImages([...selectedImages, ...mockImages]);
  };

  const handleRemoveImage = (index: number) => {
    setSelectedImages(selectedImages.filter((_, i) => i !== index));
  };

  const handlePublish = () => {
    // 模拟发布
    console.log('Publishing:', { title, content, selectedImages, selectedTopic });
    onClose?.();
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-white z-50"
    >
      {/* 顶部导航 */}
      <div className="flex items-center justify-between px-4 py-3 border-b border-gray-100">
        <motion.button
          whileTap={{ scale: 0.9 }}
          onClick={onClose}
          className="p-1"
        >
          <X className="w-6 h-6 text-gray-700" />
        </motion.button>
        <h1 className="text-lg font-semibold text-gray-900">发布笔记</h1>
        <motion.button
          whileTap={{ scale: 0.95 }}
          onClick={handlePublish}
          disabled={!title && !content && selectedImages.length === 0}
          className={cn(
            'px-4 py-1.5 rounded-full text-sm font-medium transition-colors',
            title || content || selectedImages.length > 0
              ? 'bg-[#FF2442] text-white'
              : 'bg-gray-200 text-gray-400'
          )}
        >
          发布
        </motion.button>
      </div>

      {/* 内容编辑区 */}
      <div className="p-4">
        {/* 标题输入 */}
        <input
          type="text"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          placeholder="填写标题会有更多赞哦~"
          className="w-full text-lg font-medium placeholder:text-gray-400 focus:outline-none mb-4"
        />

        {/* 正文输入 */}
        <textarea
          value={content}
          onChange={(e) => setContent(e.target.value)}
          placeholder="添加正文"
          rows={6}
          className="w-full text-sm text-gray-700 placeholder:text-gray-400 resize-none focus:outline-none mb-4"
        />

        {/* 图片选择 */}
        <div className="flex flex-wrap gap-2 mb-4">
          {selectedImages.map((image, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              className="relative w-20 h-20 rounded-lg overflow-hidden"
            >
              <img
                src={image}
                alt=""
                className="w-full h-full object-cover"
              />
              <motion.button
                whileTap={{ scale: 0.9 }}
                onClick={() => handleRemoveImage(index)}
                className="absolute top-1 right-1 w-5 h-5 bg-black/50 rounded-full flex items-center justify-center"
              >
                <X className="w-3 h-3 text-white" />
              </motion.button>
            </motion.div>
          ))}
          <motion.button
            whileTap={{ scale: 0.95 }}
            onClick={handleImageSelect}
            className="w-20 h-20 bg-gray-100 rounded-lg flex flex-col items-center justify-center gap-1"
          >
            <Image className="w-6 h-6 text-gray-400" />
            <span className="text-xs text-gray-400">
              {selectedImages.length}/9
            </span>
          </motion.button>
        </div>

        {/* 话题选择 */}
        <div className="flex flex-wrap gap-2 mb-4">
          {topics.map((topic) => (
            <motion.button
              key={topic}
              whileTap={{ scale: 0.95 }}
              onClick={() => setSelectedTopic(topic === selectedTopic ? '' : topic)}
              className={cn(
                'px-3 py-1.5 text-sm rounded-full transition-colors',
                selectedTopic === topic
                  ? 'bg-[#FF2442]/10 text-[#FF2442]'
                  : 'bg-gray-100 text-gray-600'
              )}
            >
              #{topic}
            </motion.button>
          ))}
        </div>
      </div>

      {/* 底部工具栏 */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-100 px-4 py-3 safe-area-bottom">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-6">
            <motion.button whileTap={{ scale: 0.9 }} className="flex items-center gap-1">
              <Hash className="w-5 h-5 text-gray-600" />
              <span className="text-sm text-gray-600">话题</span>
            </motion.button>
            <motion.button whileTap={{ scale: 0.9 }} className="flex items-center gap-1">
              <MapPin className="w-5 h-5 text-gray-600" />
              <span className="text-sm text-gray-600">位置</span>
            </motion.button>
            <motion.button whileTap={{ scale: 0.9 }} className="flex items-center gap-1">
              <AtSign className="w-5 h-5 text-gray-600" />
              <span className="text-sm text-gray-600">提醒谁看</span>
            </motion.button>
          </div>
          <motion.button whileTap={{ scale: 0.9 }}>
            <Smile className="w-5 h-5 text-gray-600" />
          </motion.button>
        </div>
      </div>
    </motion.div>
  );
}
