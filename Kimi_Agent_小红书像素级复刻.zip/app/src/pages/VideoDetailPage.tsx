import { useState } from 'react';
import { motion } from 'framer-motion';
import { ChevronLeft, MoreHorizontal, Music } from 'lucide-react';
import type { Note } from '@/types';
import { VideoPlayer } from '@/components/VideoPlayer';
import { ActionBar } from '@/components/ActionBar';
import { cn } from '@/lib/utils';

interface VideoDetailPageProps {
  note: Note;
  onBack?: () => void;
}

export function VideoDetailPage({ note, onBack }: VideoDetailPageProps) {
  const [isExpanded, setIsExpanded] = useState(false);

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black z-50"
    >
      {/* 顶部导航 */}
      <div className="absolute top-0 left-0 right-0 z-50 flex items-center justify-between px-4 py-3">
        <motion.button
          whileTap={{ scale: 0.9 }}
          onClick={onBack}
          className="p-2 bg-black/30 rounded-full backdrop-blur-sm"
        >
          <ChevronLeft className="w-5 h-5 text-white" />
        </motion.button>
        <motion.button 
          whileTap={{ scale: 0.9 }} 
          className="p-2 bg-black/30 rounded-full backdrop-blur-sm"
        >
          <MoreHorizontal className="w-5 h-5 text-white" />
        </motion.button>
      </div>

      {/* 视频播放区域 */}
      <div className="relative w-full h-full">
        <VideoPlayer
          src={note.videoUrl || note.coverImage}
          poster={note.coverImage}
          autoPlay
          loop
        />

        {/* 右侧操作栏 */}
        <div className="absolute right-4 bottom-24 flex flex-col items-center gap-5">
          <ActionBar note={note} orientation="vertical" />
        </div>

        {/* 底部信息栏 */}
        <div className="absolute left-4 right-20 bottom-8">
          {/* 作者信息 */}
          <div className="flex items-center gap-2 mb-3">
            <img
              src={note.author.avatar}
              alt={note.author.username}
              className="w-8 h-8 rounded-full border border-white/50"
            />
            <span className="text-white text-sm font-medium">{note.author.username}</span>
            <motion.button
              whileTap={{ scale: 0.95 }}
              className="px-3 py-0.5 bg-[#FF2442] text-white text-xs rounded-full"
            >
              关注
            </motion.button>
          </div>

          {/* 视频描述 */}
          <div className="mb-3">
            <motion.p
              className={cn(
                'text-white text-sm leading-relaxed',
                !isExpanded && 'line-clamp-2'
              )}
              onClick={() => setIsExpanded(!isExpanded)}
            >
              {note.title}
              {note.content && ` ${note.content}`}
            </motion.p>
            {note.content && note.content.length > 50 && (
              <button
                onClick={() => setIsExpanded(!isExpanded)}
                className="text-white/70 text-xs mt-1"
              >
                {isExpanded ? '收起' : '展开'}
              </button>
            )}
          </div>

          {/* 话题标签 */}
          {note.tags && note.tags.length > 0 && (
            <div className="flex flex-wrap gap-2 mb-3">
              {note.tags.map((tag, index) => (
                <span
                  key={index}
                  className="text-white/80 text-sm"
                >
                  #{tag}
                </span>
              ))}
            </div>
          )}

          {/* 音乐信息 */}
          <div className="flex items-center gap-2">
            <div className="flex items-center gap-1.5 px-2 py-1 bg-black/30 rounded-full backdrop-blur-sm">
              <Music className="w-3.5 h-3.5 text-white" />
              <span className="text-white text-xs">原声 - {note.author.username}</span>
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  );
}
