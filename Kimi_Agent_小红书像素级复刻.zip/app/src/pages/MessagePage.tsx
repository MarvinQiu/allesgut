import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Heart, MessageCircle, UserPlus, Bell, ChevronRight } from 'lucide-react';
import { mockMessages } from '@/data/mockData';
import { cn } from '@/lib/utils';

type MessageType = 'all' | 'like' | 'comment' | 'follow';

interface MessageItemProps {
  type: MessageType;
  icon: React.ElementType;
  label: string;
  count?: number;
  color: string;
}

const messageTypes: MessageItemProps[] = [
  { type: 'like', icon: Heart, label: '赞和收藏', count: 3, color: 'bg-pink-100 text-pink-500' },
  { type: 'comment', icon: MessageCircle, label: '评论和@', count: 5, color: 'bg-blue-100 text-blue-500' },
  { type: 'follow', icon: UserPlus, label: '新增关注', count: 2, color: 'bg-green-100 text-green-500' },
];

export function MessagePage() {
  const [activeType, setActiveType] = useState<MessageType>('all');

  const filteredMessages = activeType === 'all' 
    ? mockMessages 
    : mockMessages.filter(msg => msg.type === activeType);

  const formatTime = (timeString: string): string => {
    const now = new Date();
    const time = new Date(timeString);
    const diff = now.getTime() - time.getTime();
    const minutes = Math.floor(diff / 60000);
    const hours = Math.floor(diff / 3600000);
    const days = Math.floor(diff / 86400000);

    if (minutes < 60) return `${minutes}分钟前`;
    if (hours < 24) return `${hours}小时前`;
    if (days < 7) return `${days}天前`;
    return timeString.split(' ')[0];
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="min-h-screen bg-gray-50 pb-20"
    >
      {/* 顶部标题 */}
      <div className="sticky top-0 z-50 bg-white border-b border-gray-100">
        <div className="flex items-center justify-between px-4 py-3">
          <h1 className="text-lg font-semibold text-gray-900">消息</h1>
          <motion.button
            whileTap={{ scale: 0.9 }}
            className="p-2"
          >
            <span className="text-sm text-gray-600">一键已读</span>
          </motion.button>
        </div>
      </div>

      {/* 消息类型 */}
      <div className="bg-white px-4 py-4 mb-2">
        <div className="grid grid-cols-3 gap-4">
          {messageTypes.map((item) => {
            const Icon = item.icon;
            return (
              <motion.button
                key={item.type}
                whileTap={{ scale: 0.95 }}
                onClick={() => setActiveType(item.type)}
                className="flex flex-col items-center gap-2"
              >
                <div className={cn('relative w-12 h-12 rounded-full flex items-center justify-center', item.color)}>
                  <Icon className="w-6 h-6" />
                  {item.count && item.count > 0 && (
                    <span className="absolute -top-1 -right-1 w-5 h-5 bg-[#FF2442] text-white text-xs rounded-full flex items-center justify-center">
                      {item.count}
                    </span>
                  )}
                </div>
                <span className="text-xs text-gray-700">{item.label}</span>
              </motion.button>
            );
          })}
        </div>
      </div>

      {/* 消息列表 */}
      <div className="bg-white">
        <AnimatePresence mode="wait">
          <motion.div
            key={activeType}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            {filteredMessages.length > 0 ? (
              filteredMessages.map((message, index) => (
                <motion.div
                  key={message.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.05 }}
                  className="flex items-center gap-3 px-4 py-3 border-b border-gray-100"
                >
                  {/* 头像 */}
                  <div className="relative">
                    <img
                      src={message.fromUser?.avatar}
                      alt={message.fromUser?.username}
                      className="w-12 h-12 rounded-full object-cover"
                    />
                    {!message.isRead && (
                      <span className="absolute -top-0.5 -right-0.5 w-3 h-3 bg-[#FF2442] rounded-full border-2 border-white" />
                    )}
                  </div>

                  {/* 内容 */}
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-gray-900">
                      {message.fromUser?.username}
                    </p>
                    <p className="text-sm text-gray-500 truncate">
                      {message.content}
                    </p>
                  </div>

                  {/* 时间和预览 */}
                  <div className="flex flex-col items-end gap-1">
                    <span className="text-xs text-gray-400">
                      {formatTime(message.createdAt)}
                    </span>
                    {message.note && (
                      <img
                        src={message.note.coverImage}
                        alt=""
                        className="w-10 h-10 rounded object-cover"
                      />
                    )}
                  </div>
                </motion.div>
              ))
            ) : (
              <div className="flex flex-col items-center justify-center py-20">
                <div className="w-20 h-20 bg-gray-100 rounded-full flex items-center justify-center mb-4">
                  <Bell className="w-8 h-8 text-gray-400" />
                </div>
                <p className="text-gray-500 text-sm">暂无消息</p>
              </div>
            )}
          </motion.div>
        </AnimatePresence>
      </div>

      {/* 私信入口 */}
      <motion.div
        whileTap={{ scale: 0.98 }}
        className="mt-2 bg-white px-4 py-3 flex items-center justify-between"
      >
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 bg-[#FF2442]/10 rounded-full flex items-center justify-center">
            <MessageCircle className="w-6 h-6 text-[#FF2442]" />
          </div>
          <div>
            <p className="text-sm font-medium text-gray-900">私信</p>
            <p className="text-xs text-gray-500">查看私信消息</p>
          </div>
        </div>
        <ChevronRight className="w-5 h-5 text-gray-400" />
      </motion.div>
    </motion.div>
  );
}
