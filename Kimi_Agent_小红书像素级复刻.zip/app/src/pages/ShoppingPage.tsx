import { useState } from 'react';
import { motion } from 'framer-motion';
import { ShoppingCart, Filter } from 'lucide-react';
import { SearchBar } from '@/components/SearchBar';
import { cn } from '@/lib/utils';

interface Product {
  id: string;
  name: string;
  price: number;
  originalPrice?: number;
  image: string;
  sales: number;
  shopName: string;
}

const mockProducts: Product[] = [
  {
    id: 'p1',
    name: '小红书同款ins风马克杯',
    price: 29.9,
    originalPrice: 49.9,
    image: 'https://images.unsplash.com/photo-1514228742587-6b1558fcca3d?w=400&h=400&fit=crop',
    sales: 1200,
    shopName: '生活好物店',
  },
  {
    id: 'p2',
    name: '网红同款香薰蜡烛',
    price: 59.9,
    image: 'https://images.unsplash.com/photo-1602825267689-1ac462a0e5fe?w=400&h=400&fit=crop',
    sales: 856,
    shopName: '香氛小铺',
  },
  {
    id: 'p3',
    name: '简约北欧风收纳盒',
    price: 39.9,
    originalPrice: 59.9,
    image: 'https://images.unsplash.com/photo-1594040226829-7f251ab46d80?w=400&h=400&fit=crop',
    sales: 2300,
    shopName: '收纳专家',
  },
  {
    id: 'p4',
    name: '手工陶瓷花瓶',
    price: 89.9,
    image: 'https://images.unsplash.com/photo-1578500494198-246f612d3b3d?w=400&h=400&fit=crop',
    sales: 456,
    shopName: '陶艺工坊',
  },
  {
    id: 'p5',
    name: 'ins风绿植盆栽',
    price: 45.9,
    originalPrice: 69.9,
    image: 'https://images.unsplash.com/photo-1485955900006-10f4d324d411?w=400&h=400&fit=crop',
    sales: 3200,
    shopName: '绿植生活馆',
  },
  {
    id: 'p6',
    name: '复古木质相框',
    price: 35.9,
    image: 'https://images.unsplash.com/photo-1513519245088-0e12902e35a6?w=400&h=400&fit=crop',
    sales: 678,
    shopName: '家居装饰',
  },
];

const categories = [
  { id: 'all', name: '全部' },
  { id: 'beauty', name: '美妆' },
  { id: 'fashion', name: '服饰' },
  { id: 'food', name: '食品' },
  { id: 'home', name: '家居' },
  { id: 'digital', name: '数码' },
];

export function ShoppingPage() {
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [cartCount] = useState(2);

  const formatPrice = (price: number): string => {
    return price.toFixed(2);
  };

  const formatSales = (sales: number): string => {
    if (sales >= 10000) {
      return (sales / 10000).toFixed(1) + '万';
    }
    return sales.toString();
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="min-h-screen bg-gray-50 pb-20"
    >
      {/* 顶部导航 */}
      <div className="sticky top-0 z-50 bg-white border-b border-gray-100">
        <div className="flex items-center gap-3 px-4 py-3">
          <div className="flex-1">
            <SearchBar placeholder="搜索商品、品牌" />
          </div>
          <motion.button
            whileTap={{ scale: 0.9 }}
            className="p-2 relative"
          >
            <ShoppingCart className="w-5 h-5 text-gray-700" />
            {cartCount > 0 && (
              <span className="absolute top-0 right-0 w-4 h-4 bg-[#FF2442] text-white text-[10px] rounded-full flex items-center justify-center">
                {cartCount}
              </span>
            )}
          </motion.button>
        </div>

        {/* 分类标签 */}
        <div className="flex items-center gap-1 px-4 py-2 overflow-x-auto scrollbar-hide">
          {categories.map((category) => (
            <motion.button
              key={category.id}
              whileTap={{ scale: 0.95 }}
              onClick={() => setSelectedCategory(category.id)}
              className={cn(
                'px-4 py-1.5 text-sm whitespace-nowrap rounded-full transition-colors',
                selectedCategory === category.id
                  ? 'bg-[#FF2442] text-white'
                  : 'bg-gray-100 text-gray-700'
              )}
            >
              {category.name}
            </motion.button>
          ))}
        </div>
      </div>

      {/* 商品列表 */}
      <div className="p-2">
        <div className="grid grid-cols-2 gap-2">
          {mockProducts.map((product, index) => (
            <motion.div
              key={product.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.05 }}
              whileTap={{ scale: 0.98 }}
              className="bg-white rounded-lg overflow-hidden shadow-sm"
            >
              {/* 商品图片 */}
              <div className="aspect-square overflow-hidden">
                <img
                  src={product.image}
                  alt={product.name}
                  className="w-full h-full object-cover"
                />
              </div>

              {/* 商品信息 */}
              <div className="p-3">
                <h3 className="text-sm text-gray-900 line-clamp-2 mb-2">
                  {product.name}
                </h3>
                
                <div className="flex items-end gap-2 mb-1">
                  <span className="text-lg font-bold text-[#FF2442]">
                    ¥{formatPrice(product.price)}
                  </span>
                  {product.originalPrice && (
                    <span className="text-xs text-gray-400 line-through">
                      ¥{formatPrice(product.originalPrice)}
                    </span>
                  )}
                </div>

                <div className="flex items-center justify-between">
                  <span className="text-xs text-gray-500">
                    {formatSales(product.sales)}人付款
                  </span>
                  <span className="text-xs text-gray-400">
                    {product.shopName}
                  </span>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>

      {/* 推荐商品 */}
      <div className="mt-4 px-4">
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-sm font-medium text-gray-900">猜你喜欢</h3>
          <motion.button
            whileTap={{ scale: 0.95 }}
            className="flex items-center gap-1 text-xs text-gray-500"
          >
            <Filter className="w-3.5 h-3.5" />
            筛选
          </motion.button>
        </div>
      </div>
    </motion.div>
  );
}
