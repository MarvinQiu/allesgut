// 用户类型
export interface User {
  id: string;
  username: string;
  avatar: string;
  bio?: string;
  followers: number;
  following: number;
  likes: number;
  isVerified?: boolean;
  location?: string;
}

// 笔记类型
export interface Note {
  id: string;
  title: string;
  content?: string;
  images: string[];
  videoUrl?: string;
  coverImage: string;
  author: User;
  likes: number;
  comments: number;
  collects: number;
  isVideo: boolean;
  category: string;
  tags: string[];
  location?: string;
  createdAt: string;
  isLiked?: boolean;
  isCollected?: boolean;
}

// 评论类型
export interface Comment {
  id: string;
  content: string;
  author: User;
  likes: number;
  createdAt: string;
  replies?: Comment[];
}

// 消息类型
export interface Message {
  id: string;
  type: 'like' | 'comment' | 'follow' | 'system';
  content: string;
  fromUser?: User;
  note?: Note;
  createdAt: string;
  isRead: boolean;
}

// 分类类型
export interface Category {
  id: string;
  name: string;
  icon?: string;
}

// 搜索历史类型
export interface SearchHistory {
  id: string;
  keyword: string;
  createdAt: string;
}

// 底部导航项
export type TabType = 'home' | 'shopping' | 'publish' | 'message' | 'profile';
