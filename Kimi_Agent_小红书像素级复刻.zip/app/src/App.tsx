import { useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { BottomNav } from '@/components/BottomNav';
import { HomePage } from '@/pages/HomePage';
import { SearchPage } from '@/pages/SearchPage';
import { NoteDetailPage } from '@/pages/NoteDetailPage';
import { VideoDetailPage } from '@/pages/VideoDetailPage';
import { ProfilePage } from '@/pages/ProfilePage';
import { MessagePage } from '@/pages/MessagePage';
import { ShoppingPage } from '@/pages/ShoppingPage';
import { PublishPage } from '@/pages/PublishPage';
import { useAppStore } from '@/stores/useAppStore';
import type { Note } from '@/types';
import './App.css';

type PageType = 'main' | 'search' | 'note' | 'video' | 'publish';

function App() {
  const { currentTab } = useAppStore();
  const [currentPage, setCurrentPage] = useState<PageType>('main');
  const [selectedNote, setSelectedNote] = useState<Note | null>(null);
  const [showPublish, setShowPublish] = useState(false);

  const handleNoteClick = (note: Note) => {
    setSelectedNote(note);
    if (note.isVideo) {
      setCurrentPage('video');
    } else {
      setCurrentPage('note');
    }
  };

  const handleBack = () => {
    setCurrentPage('main');
    setSelectedNote(null);
  };

  const handleSearchClick = () => {
    setCurrentPage('search');
  };

  const handlePublishClick = () => {
    setShowPublish(true);
  };

  const handlePublishClose = () => {
    setShowPublish(false);
  };

  // 渲染主内容区域
  const renderMainContent = () => {
    switch (currentTab) {
      case 'home':
        return (
          <HomePage
            onNoteClick={handleNoteClick}
            onSearchClick={handleSearchClick}
          />
        );
      case 'shopping':
        return <ShoppingPage />;
      case 'message':
        return <MessagePage />;
      case 'profile':
        return (
          <ProfilePage
            onNoteClick={handleNoteClick}
            onBack={handleBack}
          />
        );
      default:
        return (
          <HomePage
            onNoteClick={handleNoteClick}
            onSearchClick={handleSearchClick}
          />
        );
    }
  };

  return (
    <div className="relative min-h-screen bg-white max-w-md mx-auto overflow-hidden">
      {/* 发布页面 */}
      <AnimatePresence>
        {showPublish && (
          <PublishPage onClose={handlePublishClose} />
        )}
      </AnimatePresence>

      {/* 搜索页面 */}
      <AnimatePresence>
        {currentPage === 'search' && (
          <div className="fixed inset-0 z-40">
            <SearchPage onBack={handleBack} />
          </div>
        )}
      </AnimatePresence>

      {/* 笔记详情页 */}
      <AnimatePresence>
        {currentPage === 'note' && selectedNote && (
          <div className="fixed inset-0 z-40">
            <NoteDetailPage note={selectedNote} onBack={handleBack} />
          </div>
        )}
      </AnimatePresence>

      {/* 视频详情页 */}
      <AnimatePresence>
        {currentPage === 'video' && selectedNote && (
          <VideoDetailPage note={selectedNote} onBack={handleBack} />
        )}
      </AnimatePresence>

      {/* 主页面 */}
      <AnimatePresence mode="wait">
        {currentPage === 'main' && (
          <motion.div
            key="main"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="min-h-screen"
          >
            {renderMainContent()}
          </motion.div>
        )}
      </AnimatePresence>

      {/* 底部导航栏 - 只在主页面显示 */}
      {currentPage === 'main' && !showPublish && (
        <div onClick={(e) => {
          const target = e.target as HTMLElement;
          if (target.closest('[data-publish]') || target.textContent?.includes('发布')) {
            handlePublishClick();
          }
        }}>
          <BottomNav />
        </div>
      )}
    </div>
  );
}

export default App;
