# 小红书 App 技术规范

## 组件清单

### shadcn/ui 组件
| 组件 | 用途 |
|-----|------|
| Button | 按钮交互 |
| Card | 卡片容器 |
| Input | 输入框 |
| Tabs | 标签切换 |
| Avatar | 用户头像 |
| Badge | 徽章标记 |
| Separator | 分隔线 |
| ScrollArea | 滚动区域 |
| Sheet | 底部弹窗 |
| Dialog | 对话框 |
| DropdownMenu | 下拉菜单 |
| Toast | 消息提示 |

### 自定义组件
| 组件 | 用途 | 位置 |
|-----|------|------|
| BottomNav | 底部导航栏 | components/BottomNav.tsx |
| NoteCard | 笔记卡片 | components/NoteCard.tsx |
| MasonryGrid | 瀑布流布局 | components/MasonryGrid.tsx |
| VideoPlayer | 视频播放器 | components/VideoPlayer.tsx |
| CategoryTabs | 分类标签栏 | components/CategoryTabs.tsx |
| SearchBar | 搜索栏 | components/SearchBar.tsx |
| UserHeader | 用户主页头部 | components/UserHeader.tsx |
| ActionBar | 视频右侧操作栏 | components/ActionBar.tsx |
| LikeButton | 点赞按钮(带动画) | components/LikeButton.tsx |
| CollectButton | 收藏按钮(带动画) | components/CollectButton.tsx |

## 动画实现规划

| 动画 | 库 | 实现方式 | 复杂度 |
|-----|---|---------|-------|
| 页面切换 | Framer Motion | AnimatePresence + motion.div | 中 |
| 点赞动画 | Framer Motion | scale + color 关键帧 | 低 |
| 收藏动画 | Framer Motion | rotate + scale 关键帧 | 低 |
| 瀑布流加载 | Framer Motion | staggerChildren | 中 |
| Tab 指示器滑动 | Framer Motion | layoutId 共享布局 | 低 |
| 下拉刷新 | Framer Motion | drag + snap | 中 |
| 视频播放控制 | CSS + State | opacity + scale 过渡 | 低 |
| 底部导航切换 | Framer Motion | fade + slide | 低 |
| 卡片悬停效果 | CSS | transform + shadow | 低 |
| 发布按钮按压 | Framer Motion | whileTap scale | 低 |

## 项目文件结构

```
src/
├── components/           # 可复用组件
│   ├── ui/              # shadcn/ui 组件
│   ├── BottomNav.tsx
│   ├── NoteCard.tsx
│   ├── MasonryGrid.tsx
│   ├── VideoPlayer.tsx
│   ├── CategoryTabs.tsx
│   ├── SearchBar.tsx
│   ├── UserHeader.tsx
│   ├── ActionBar.tsx
│   ├── LikeButton.tsx
│   ├── CollectButton.tsx
│   └── ShareButton.tsx
├── pages/               # 页面组件
│   ├── HomePage.tsx
│   ├── DiscoverPage.tsx
│   ├── PublishPage.tsx
│   ├── MessagePage.tsx
│   ├── ProfilePage.tsx
│   ├── NoteDetailPage.tsx
│   ├── VideoDetailPage.tsx
│   └── SearchPage.tsx
├── hooks/               # 自定义 Hooks
│   ├── useScrollPosition.ts
│   ├── useInfiniteScroll.ts
│   ├── useVideoPlayer.ts
│   └── useLikeAnimation.ts
├── stores/              # 状态管理
│   ├── useAppStore.ts
│   ├── useUserStore.ts
│   └── useNoteStore.ts
├── types/               # TypeScript 类型
│   └── index.ts
├── data/                # 模拟数据
│   └── mockData.ts
├── lib/                 # 工具函数
│   └── utils.ts
├── App.tsx
└── main.tsx
```

## 依赖清单

### 核心依赖
```json
{
  "dependencies": {
    "react": "^18.2.0",
    "react-dom": "^18.2.0",
    "react-router-dom": "^6.20.0",
    "framer-motion": "^10.16.0",
    "zustand": "^4.4.0",
    "lucide-react": "^0.294.0",
    "clsx": "^2.0.0",
    "tailwind-merge": "^2.0.0"
  }
}
```

### 开发依赖
- TypeScript
- Vite
- Tailwind CSS
- ESLint
- Prettier

## 状态管理设计

### App Store
```typescript
interface AppState {
  currentTab: 'home' | 'shopping' | 'publish' | 'message' | 'profile';
  searchQuery: string;
  selectedCategory: string;
  isLoading: boolean;
  setCurrentTab: (tab: string) => void;
  setSearchQuery: (query: string) => void;
  setSelectedCategory: (category: string) => void;
}
```

### User Store
```typescript
interface UserState {
  user: User | null;
  isLoggedIn: boolean;
  followers: number;
  following: number;
  likes: number;
  setUser: (user: User) => void;
  logout: () => void;
}
```

### Note Store
```typescript
interface NoteState {
  notes: Note[];
  currentNote: Note | null;
  likedNotes: string[];
  collectedNotes: string[];
  fetchNotes: () => Promise<void>;
  likeNote: (id: string) => void;
  collectNote: (id: string) => void;
}
```

## 路由设计

| 路径 | 页面 | 说明 |
|-----|------|------|
| / | HomePage | 首页/发现页 |
| /search | SearchPage | 搜索页 |
| /note/:id | NoteDetailPage | 图文笔记详情 |
| /video/:id | VideoDetailPage | 视频笔记详情 |
| /profile/:id | ProfilePage | 个人主页 |
| /message | MessagePage | 消息页 |
| /publish | PublishPage | 发布页 |

## 性能优化策略

1. **图片优化**
   - 使用懒加载
   - 自适应图片尺寸
   - WebP 格式优先

2. **视频优化**
   - 懒加载视频
   - 预加载首帧
   - 自适应码率

3. **代码优化**
   - 组件懒加载
   - 虚拟列表 (长列表)
   - 防抖节流

4. **动画优化**
   - GPU 加速
   - will-change 属性
   - 减少重绘重排
